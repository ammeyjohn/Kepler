/*
	Window displaying the list of tokens comprising the current path.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PathFrame extends JFrame
{
	protected int length; // displays a max of this many chars from the path
	public static final int LENGTH_DEFAULT=1000; 

	private final JTextArea pathArea;       // displays path chars
	private final IntegerField lengthField; // displays the length to chop chars at

	public PathFrame()
	{
		super("Path");

		length=LENGTH_DEFAULT;

		pathArea=new JTextArea(8,40);
		pathArea.setEditable(false);      // read-only
		pathArea.setLineWrap(true);       // wraps lines
		pathArea.setWrapStyleWord(false); // breaks lines by char (not word)

		lengthField=new IntegerField(length,0,Integer.MAX_VALUE,100);
		lengthField.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce) { setLength(lengthField.getValue()); }
		});

		JPanel contentPane=new JPanel(new BorderLayout());
		contentPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

		contentPane.add("Center",new JScrollPane(pathArea));

		Box lengthBox=new Box(BoxLayout.X_AXIS);
		lengthBox.add(new JLabel("Show first "));
		lengthBox.add(lengthField);
		lengthBox.add(new JLabel(" tokens."));
		contentPane.add("South",lengthBox);

		setContentPane(contentPane);
		pack();
        setLocation(830,735);
	}

/*
	Accessor methods.
*/
	public void setLength(int length)
	{
		if(length<0) length=0;
		this.length=length;
		setPath(pathArea.getText().toCharArray());
	}

	public void setPath(char[] path)
	{
		if(path==null) path=new char[0];
		int count=Math.min(path.length,length);
		pathArea.setText(new String(path,0,count));
	}

	public int getLength() { return(length); }
}

