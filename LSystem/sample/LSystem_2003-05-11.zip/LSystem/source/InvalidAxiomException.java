public class InvalidAxiomException extends Exception { }
