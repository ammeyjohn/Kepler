public class AliasNotDefinedException extends Exception { }
