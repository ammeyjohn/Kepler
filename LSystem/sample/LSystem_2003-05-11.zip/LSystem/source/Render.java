/*
	Stores information about a particular rendering.
*/

import java.awt.image.*;
import java.awt.geom.*;
import java.awt.color.*;
import java.awt.Dimension;
import javax.swing.event.*;

public class Render implements ChangeListener
{
	Preset preset;  // Preset information
	int iteration;  // Iteration number
	int width;      // Width of render
	int height;     // Height of render

	BufferedImage[] images; // Main image
	int swapped;            // Whether orientation is swapped
	int inverted;           // Whether picture has been color inverted
	static final int SWP=1; // Shadow variable for accessing image
	static final int INV=2; // Shadow variable for accessing image

	Factory factory; // used to do actual rendering

	EventListenerList listenerList; // List of listenerList to inform

	public static final int WIDTH_DEFAULT=600;
	public static final int HEIGHT_DEFAULT=600;

/*
	Constructs a new render guy.
*/
	public Render(Preset preset,int iteration,int width,int height)
	{
		this.preset=preset;
		this.iteration=iteration;
		this.width=width;
		this.height=height;

		images=new BufferedImage[4];

		swapped=0;
		inverted=0;

		preset.addChangeListener(this);

		listenerList=new EventListenerList();

		setFactory(new Factory(this));
	}

	public Render(Preset preset) { this(preset,0,WIDTH_DEFAULT,HEIGHT_DEFAULT); }
	public Render() { this(new Preset(),0,WIDTH_DEFAULT,HEIGHT_DEFAULT); }

/*
	Begins rendering an image based on the current state of this Render.
*/
	public void startRender(boolean makePath)
	{
		Factory f=new Factory(this,makePath);
		f.addChangeListener(this);
		setFactory(f);
		f.start();
	}

/*
	Stops the given render in mid-step.
*/
	public void interruptRender()
	{
		getFactory().interrupt();
		try { getFactory().join(); }
		catch(InterruptedException ie) { }
	}

/*
	Updates based on changes signaled by preset.
*/
	public void stateChanged(ChangeEvent ce)
	{
		if((ce instanceof PresetChangeEvent) && ((PresetChangeEvent)ce).getType()!=PresetChangeEvent.DESCRIPTION)
			clearImages();
		fireChangeEvent(ce);
	}

	public BufferedImage getImage()
	{ 
		if(images[0]==null) images[0]=getFactory().getImage();
		update();

		return(images[swapped|inverted]); 
	}

	void clearImages() { images=new BufferedImage[4]; }

	void update()
	{
		if(images[swapped|inverted]==null)
		{
			if(isSwapped())
			{
				images[SWP]=swap(images[0]);
				if(isInverted())
					images[SWP|INV]=invert(images[SWP]);
			}
			else if(isInverted())
				images[INV]=invert(images[0]);
		}
	}

	public int getFCount() { return(getFactory().getFCount()); }

/*
	Returns a new image that is the inverse of the input.
*/
	public static BufferedImage invert(BufferedImage in)
	{
		LookupTable lt=new LookupTable(0,3)
		{
			public int[] lookupPixel(int[] src,int[] dest)
			{
				if(dest==null) dest=new int[3];

				if((src[0]|src[1]|src[2])==0)
					for(int j=0;j<dest.length;j++) dest[j]=0xFF;
				else for(int j=0;j<dest.length;j++) dest[j]=src[j];

				return(dest);
			}
		};

		LookupOp invertOp=new LookupOp(lt,null);

		// apply the invert to a BufferedImage called source
		return(invertOp.filter(in,new BufferedImage(in.getWidth(),in.getHeight(),in.getType())));
	}

/*
	Returns a new image that is the swap of the input.
*/
	public static BufferedImage swap(BufferedImage in)
	{
		AffineTransformOp ato=new AffineTransformOp(AffineTransform.getRotateInstance(-Math.PI/2,in.getWidth()/2,in.getHeight()/2),null);
		return(ato.filter(in,null));
	}

	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	void fireChangeEvent(ChangeEvent ce)
	{
		Object[] listeners=listenerList.getListenerList();
		for(int j=listeners.length-2;j>=0;j-=2)
			if(listeners[j]==ChangeListener.class)
				((ChangeListener)listeners[j+1]).stateChanged(ce);
	}
	void fireChangeEvent(Object source) { fireChangeEvent(new ChangeEvent(source)); }
	void fireChangeEvent() { fireChangeEvent(this); }

/*
	Accessor methods.
*/
	public boolean isSwapped() { return(swapped==SWP); }
	public boolean isInverted() { return(inverted==INV); }

	public Preset getPreset() { return(preset); }
	public int getIteration() { return(iteration); }
	public int getWidth() { return(width); }
	public int getHeight() { return(height); }

	public Factory getFactory() { return(factory); }

	public void setPreset(Preset preset) { this.preset=preset; clearImages(); fireChangeEvent(); }
	public void setIteration(int iteration) { this.iteration=iteration; clearImages(); fireChangeEvent(); }
	public void setWidth(int width) { this.width=width; clearImages(); fireChangeEvent(); }
	public void setHeight(int height) { this.height=height; clearImages(); fireChangeEvent(); }
	public void setSize(int width,int height) { this.width=width; this.height=height; clearImages(); fireChangeEvent(); }

	public void setFactory(Factory factory) { this.factory=factory; }

	public void setSwapped(boolean swapped)
	{
		if(swapped) this.swapped=SWP;
		else this.swapped=0;
	}

	public void setInverted(boolean inverted)
	{
		if(inverted) this.inverted=INV;
		else this.inverted=0;
	}
}

