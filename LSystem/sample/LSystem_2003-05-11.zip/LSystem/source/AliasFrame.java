/*
	Displays an editable list of aliases (rules or definitions) for the given Preset.
	NOTE: clicking delete should remove the selected alias. How do you do that in Swing?
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.List;

public class AliasFrame extends JFrame
{
	protected Preset preset;
	protected int type;
	protected JList list;
	protected final Action add,edit,delete; 
	
	public AliasFrame(Preset preset,int type)
	{
		super(Alias.getTypeName(type)+"s: "+preset.getDescription());
		
		this.preset=preset;
		this.type=type;
		
		add=new AddAction(type);
		edit=new EditAction(type);
		delete=new DeleteAction(type);
		
		JMenuBar mb=new JMenuBar();
		JMenu menu=new JMenu(Alias.getTypeName(type)+"s");
		menu.add(add);
		menu.add(edit);
		menu.add(delete);
		mb.add(menu);
		setJMenuBar(mb);
		
		list=new JList(new AliasListModel(type));
		list.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//list.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) { doEdit(); } });
		list.addMouseListener(new MouseAdapter() { 
			public void mouseClicked(MouseEvent me) 
			{ 
				if(me.getClickCount()==2)
				{
					if(list.getSelectedIndex()==-1) doAdd();
					else doEdit(); 
				}
			} 
		});
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e)
			{
				edit.setEnabled(list.getSelectedIndex()!=-1);
				delete.setEnabled(list.getSelectedIndex()!=-1);
			}
		});
		
		if(list.getModel().getSize()>0)
			list.setSelectedIndex(0);
		else
		{
			edit.setEnabled(false);
			delete.setEnabled(false);
		}
		
		JPanel listPanel=new JPanel();
		listPanel.setLayout(new BorderLayout());
		listPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		listPanel.add("Center",new JScrollPane(list));
		
		getContentPane().add("Center",listPanel);
		
		pack();
        if(type==Alias.RULE) setLocation(830,335);
        else setLocation(830,535);
	}
	
	protected void doAdd()
	{
		AliasEditor ae=new AliasEditor(this,preset,type);
		ae.setVisible(true);
		Alias a=ae.getAlias();
		if(a!=null) ((AliasListModel)list.getModel()).add(a);
	}
	
	protected void doEdit()
	{
		int index=list.getSelectedIndex();
		Alias oldAlias=((AliasListModel)list.getModel()).get(index);
		AliasEditor ae=new AliasEditor(this,preset,oldAlias);
		ae.setVisible(true);
		Alias a=ae.getAlias();
		if(a!=null) ((AliasListModel)list.getModel()).set(index,a);
	}
	
	protected void doDelete()
	{
		int index=list.getSelectedIndex();
		((AliasListModel)list.getModel()).remove(index);
	}
	
	private class AliasListModel extends AbstractListModel
	{
		protected int type;
		public AliasListModel(int type) { this.type=type; }
		public Object getElementAt(int index) { return(preset.getAlias(index,type)); }
		public int getSize() { return(preset.getAliasCount(type)); }
		
		public void add(Alias a)
		{
			preset.addAlias(a,type);
			fireIntervalAdded(this,getSize()-1,getSize()-1);
		}
		
		public void set(int index,Alias a)
		{
			preset.setAlias(index,a,type);
			fireContentsChanged(this,index,index);
		}
		
		public void remove(int index)
		{
			preset.removeAlias(index,type);
			fireIntervalRemoved(this,index,index);
		}
		
		public void update() { fireContentsChanged(this,0,getSize()); }
		
		public Alias get(int index) { return(preset.getAlias(index,type)); }
	}

	public Preset getPreset() { return(preset); }
	public int getType() { return(type); }

	public void setPreset(Preset preset) 
	{ 
		this.preset=preset; 
		((AliasListModel)list.getModel()).update();
		updateTitle();
	}
	
	public void updateTitle() { setTitle(Alias.getTypeName(type)+"s: "+preset.getDescription()); }
	
	private class AddAction extends AbstractAction
	{
		public AddAction(int type) { super("Add "+Alias.getTypeName(type)); }
		public void actionPerformed(ActionEvent e) { doAdd(); }
	}

	private class EditAction extends AbstractAction
	{
		public EditAction(int type) { super("Edit "+Alias.getTypeName(type)); }
		public void actionPerformed(ActionEvent e) { doEdit(); }
	}

	private class DeleteAction extends AbstractAction
	{
		public DeleteAction(int type) { super("Delete "+Alias.getTypeName(type)); }
		public void actionPerformed(ActionEvent e) { doDelete(); }
	}
}
