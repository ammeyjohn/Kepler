public class IllegalTypeException extends IllegalArgumentException
{
	public IllegalTypeException() { super("type must be Alias.RULE or Alias.DEFINITION"); }
}
