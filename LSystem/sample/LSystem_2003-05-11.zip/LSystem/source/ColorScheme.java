/*
	Store defining information for a color scheme.
*/

import java.io.*;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.event.*;

public class ColorScheme extends Object
{
	public static final String COLORS="colors/";  // Location of colors
	public static final int TYPE_INDEXED=0;       // Indexed color scheme
	public static final int TYPE_DISCRETE=1;      // Discrete color scheme
	public static final int TYPE_CONTINUOUS=2;    // Interpolated color scheme
	public static final String COLOR_SCHEME_SUFFIX=".lcd";

	String name;           // Name of this color preset
	String description;    // Short description of color preset
	ArrayList crs;         // List of color ranges
	int type;              // Color scheme type
	double cycles;         // Number of times to cycle hues
	int disc;              // Cycle length for discrete

	EventListenerList listenerList;

	// Default values
	public static final String NAME_DEFAULT="untitled";
	public static final String DESCRIPTION_DEFAULT="Untitled";
	public static final int TYPE_DEFAULT=TYPE_INDEXED;
	public static final double CYCLES_DEFAULT=1.0;

/*
	Creates an empty color preset.
*/
	ColorScheme()
	{
		name=NAME_DEFAULT;
		description=DESCRIPTION_DEFAULT;
		type=TYPE_DEFAULT;
		cycles=CYCLES_DEFAULT;
		crs=new ArrayList();

		listenerList=new EventListenerList();
	}

	public Color getIndexedColor(int index)
	{
		index=index%((int)getRange(getColorRangeCount()-1)+1);
		//System.out.println(index);
		int j;
		for(j=0;j<getColorRangeCount()&&getRange(j)<=index;j++);
		//System.out.println(j);
		return(getColor(j-1));
	}

	public Color getDiscreteColor(int fCount)
	{
		int n=fCount%disc;
		int sum=0;
		int j;
		for(j=0;j<getColorRangeCount()&&sum<=n;j++) sum+=getRange(j);
		return(getColor(j-1));
	}

	public Color getContinuousColor(int fCount,int fTotal)
	{
		//System.out.println();
		//System.out.println("fc: "+fCount+" ft: "+fTotal);
		double part=fTotal/cycles;
		double pct=(double)(fCount%part)/part;
		//System.out.println("pct: "+pct);
		int j;
		for(j=0;j<getColorRangeCount()&&getRange(j)<pct;j++);

		Color color;
		if(j==0) {/*System.out.println("lfp");*/color=getColor(0);}
		else if(j==getColorRangeCount()) {/*System.out.println("rfp");*/color=getColor(getColorRangeCount()-1);}
		else
		{
			//System.out.println("j: "+j+" "+getRangeDouble(j-1)+"<"+pct+"<"+getRangeDouble(j));
			double dist=(pct-getRange(j-1))/(getRange(j)-getRange(j-1));
			Color c1=getColor(j-1);
			Color c2=getColor(j);
			int r=c1.getRed()+(int)(dist*((double)c2.getRed()-(double)c1.getRed()));
			int g=c1.getGreen()+(int)(dist*((double)c2.getGreen()-(double)c1.getGreen()));
			int b=c1.getBlue()+(int)(dist*((double)c2.getBlue()-(double)c1.getBlue()));
			//System.out.println("dist: "+dist+" r: "+r+" g: "+g+" b: "+b);
			color=new Color(r,g,b);
		}
		//System.out.println(color);

		return(color);
	}

	public void addColorRange(ColorRange cr) { crs.add(cr); calculateDisc(); fireChangeEvent(); }
	public void addColorRange(Color c,double r) { crs.add(new ColorRange(c,r)); }
	public void removeColorRange(int index) { crs.remove(index); calculateDisc(); fireChangeEvent(); }
	public void setColorRange(int index,ColorRange cr) { crs.set(index,cr); calculateDisc(); fireChangeEvent(); }
	public void setColorRange(int index,Color c,double r) { crs.set(index,new ColorRange(c,r)); }
	public ArrayList getColorRanges() { return(crs); }
	public int getColorRangeCount() { return(crs.size()); }
	public ColorRange getColorRange(int index) { return((ColorRange)crs.get(index)); }
	public Color getColor(int index) { return(getColorRange(index).getColor()); }
	public double getRange(int index) { return(getColorRange(index).getRange()); }

	public int getType() { return(type); }
	public double getCycles() { return(cycles); }
	public String getName() { return(name); }
	public String getDescription() { return(description); }

	public void setType(int type) { this.type=type; fireChangeEvent(); }
	public void setCycles(double cycles) { this.cycles=cycles; fireChangeEvent(); }
	public void setName(String name) { this.name=name; }
	public void setDescription(String description) { this.description=description; }

	public void setType(String s)
	{
		if(s.equals("indexed")) setType(TYPE_INDEXED);
		else if(s.equals("discrete")) setType(TYPE_DISCRETE);
		else setType(TYPE_CONTINUOUS);
	}

/*
	Loads a color scheme from a file.
*/
	ColorScheme(File file) throws IOException,FileFormatException
	{
		this();
		StreamTokenizer st=new StreamTokenizer(new InputStreamReader(new FileInputStream(file)));

		st.quoteChar('\"');
		st.commentChar('#');
		st.wordChars('{','{'); st.wordChars('}','}');
		st.wordChars(':',':');

		while(st.nextToken()!=StreamTokenizer.TT_EOF)
		{
			if(st.ttype==StreamTokenizer.TT_WORD)
			{
				if(st.sval.equals("Colors:"))
				{
					st.nextToken();
					if(!st.sval.equals("{")) throw(new FileFormatException());
					else
					{
						st.nextToken();
						while(st.ttype==StreamTokenizer.TT_NUMBER || (st.ttype==StreamTokenizer.TT_WORD && !st.sval.equals("}")))
						{
							double range=st.nval;

							st.nextToken();
							String s=st.sval;
							st.nextToken();
							double a=st.nval;
							st.nextToken();
							double b=st.nval;
							st.nextToken();
							double c=st.nval;

							Color color=parseColor(s,a,b,c);
						
							addColorRange(color,range);

							st.nextToken();
						}

						calculateDisc();
					}
					//System.out.println(crs);
				}
				else if(st.sval.equals("Cycles:"))
				{
					st.nextToken();
					setCycles(st.nval);
				}
				else if(st.sval.equals("Type:"))
				{
					st.nextToken();
					if(st.sval.equals("indexed")) setType(TYPE_INDEXED);
					else if(st.sval.equals("discrete")) setType(TYPE_DISCRETE);
					else if(st.sval.equals("continuous")) setType(TYPE_CONTINUOUS);
				}
				else if(st.sval.equals("Description:"))
				{
					st.nextToken();
					if((st.ttype!=StreamTokenizer.TT_WORD)&&(st.ttype!='\"'))
						throw(new FileFormatException());
					else setDescription(st.sval);
				}
				else if(st.sval.equals("Name:"))
				{
					st.nextToken();
					if((st.ttype!=StreamTokenizer.TT_WORD)&&(st.ttype!='\"'))
						throw(new FileFormatException());
					else setName(st.sval);
				}
				else { System.out.println("ur"); throw(new FileFormatException()); }
			}
			else { System.out.println("nw"); throw(new FileFormatException()); }
		}
		fireChangeEvent();
	}

	void calculateDisc()
	{
		disc=0;
		for(int j=0;j<getColorRangeCount();j++) disc+=(int)getRange(j);
	}

	public static Color parseColor(String type,double a,double b,double c)
	{
		Color color;
		if(type.equals("RGB")) color=new Color((int)a,(int)b,(int)c);
		else if(type.equals("HSB")) color=Color.getHSBColor((float)a,(float)b,(float)c);
		else color=Color.white;
		return(color);
	}

/*
	Save a freakin' set.
*/
	public void saveColorScheme(File file) throws IOException
	{
		DataOutputStream dos=new DataOutputStream(new FileOutputStream(file));
		dos.writeBytes("Name:\t"+getName()+"\n");
		dos.writeBytes("Description:\t\""+getDescription()+"\"\n");
		dos.writeBytes("Type:\t"+getType()+"\n");
		if(type==TYPE_CONTINUOUS)
			dos.writeBytes("Cycles:\t"+getCycles()+"\n");
		dos.writeBytes("Colors:\n{\n");
		for(int j=0;j<getColorRangeCount();j++)
			dos.writeBytes("\t"+getColorRange(j).toString()+"\n");
		dos.writeBytes("}\n");
	}

	public String toString()
	{
		String s="";
		for(int j=0;j<getColorRangeCount();j++)
			s+=getColorRange(j).toString()+"\n";
		return(s);
	}

/*
	Makes this class a source of ChangeEvents.
*/
	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	void fireChangeEvent(Object source)
	{
		ChangeEvent ce=new ChangeEvent(source);
		Object[] listeners=listenerList.getListenerList();
		for(int j=listeners.length-2;j>=0;j-=2) 
			if(listeners[j]==ChangeListener.class) 
				((ChangeListener)listeners[j+1]).stateChanged(ce);
	}
	void fireChangeEvent() { fireChangeEvent(this); }
}

