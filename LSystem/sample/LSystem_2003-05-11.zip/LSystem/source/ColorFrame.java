/*
	Displays a frame for changing color-scheme properties.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.FileFilter;
import java.util.List;
import java.io.*;

public class ColorFrame extends JFrame
{
	ColorScheme cs;
	Preset preset;
	SmartTextField ntf;
	SmartTextField dtf;
	DoubleField cdf;
	JComboBox tcb;
	JList list;
	Action add,edit,delete; 
	Action save,saveAs,open,close; 
	
	ColorFrame(ColorScheme cs,Preset preset)
	{
		super("Color scheme: "+cs.getDescription());
		
		this.cs=cs;
		this.preset=preset;

		initMenuBar();
		initComps();
		
		pack();
		setLocation(1117,335);
	}

	void initMenuBar()
	{
		add=new AddAction();
		edit=new EditAction();
		delete=new DeleteAction();
		save=new SaveAction();
		saveAs=new SaveAsAction();
		open=new OpenAction();
		close=new CloseAction();
		
		JMenuBar mb=new JMenuBar();

		JMenu fMenu=new JMenu("File");
		fMenu.add(save);
		fMenu.add(saveAs);
		fMenu.add(open);
		fMenu.add(close);
		mb.add(fMenu);

		JMenu csMenu=new JMenu("Colors");
		csMenu.add(add);
		csMenu.add(edit);
		csMenu.add(delete);
		mb.add(csMenu);

		setJMenuBar(mb);
	}

	void initComps()
	{
		list=new JList(new ColorRangeModel());
		list.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.addMouseListener(new MouseAdapter() { 
			public void mouseClicked(MouseEvent me) 
			{ 
				if(me.getClickCount()==2)
				{
					if(list.getSelectedIndex()==-1) doAdd();
					else doEdit(); 
				}
			} 
		});
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e)
			{
				edit.setEnabled(list.getSelectedIndex()!=-1);
				delete.setEnabled(list.getSelectedIndex()!=-1);
			}
		});
		
		if(list.getModel().getSize()>0) list.setSelectedIndex(0);
		else
		{
			edit.setEnabled(false);
			delete.setEnabled(false);
		}

		cdf=new DoubleField(cs.getCycles());

		// Create name panel
		JPanel nPanel=new JPanel();
		nPanel.setLayout(new BoxLayout(nPanel,BoxLayout.X_AXIS));
		nPanel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		nPanel.add(new JLabel("Name:"));
		nPanel.add(Box.createHorizontalStrut(10));
		ntf=new SmartTextField(cs.getName());
		ntf.addChangeListener(new ChangeListener() { public void stateChanged(ChangeEvent ce) { cs.setName(ntf.getText()); } });
		nPanel.add(ntf);
		
		// Create description panel
		JPanel dPanel=new JPanel();
		dPanel.setLayout(new BoxLayout(dPanel,BoxLayout.X_AXIS));
		dPanel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		dPanel.add(new JLabel("Description:"));
		dPanel.add(Box.createHorizontalStrut(10));
		dtf=new SmartTextField(cs.getDescription());
		dtf.addChangeListener(new ChangeListener() { public void stateChanged(ChangeEvent ce) { cs.setDescription(dtf.getText()); } });
		dPanel.add(dtf);

		// Create type panel
		JPanel tPanel=new JPanel();
		tPanel.setLayout(new BoxLayout(tPanel,BoxLayout.X_AXIS));
		tPanel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		tPanel.add(new JLabel("Type:"));
		tPanel.add(Box.createHorizontalStrut(10));
		tcb=new JComboBox();
		tcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie)
			{
				cs.setType((String)tcb.getSelectedItem());
				if(cs.getType()==ColorScheme.TYPE_CONTINUOUS) cdf.setEnabled(true);
				else cdf.setEnabled(false);
			}
		});
		tcb.addItem("indexed");
		tcb.addItem("discrete");
		tcb.addItem("continuous");
		tcb.setEditable(false);
		tcb.setSelectedIndex(cs.getType());
		tPanel.add(tcb);

		// Create top panel
		JPanel topPanel=new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
		topPanel.add(nPanel);
		topPanel.add(dPanel);
		topPanel.add(tPanel);

		JPanel listPanel=new JPanel();
		listPanel.setLayout(new BorderLayout());
		listPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		listPanel.add("Center",new JScrollPane(list));

		JPanel cPanel=new JPanel();
		cPanel.setLayout(new BoxLayout(cPanel,BoxLayout.X_AXIS));
		cPanel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
		cPanel.add(new JLabel("Cycles:"));
		cPanel.add(Box.createHorizontalStrut(10));
		cdf.addChangeListener(new ChangeListener() { public void stateChanged(ChangeEvent ce) { cs.setCycles(cdf.getValue()); } });
		cPanel.add(cdf);
		
		getContentPane().add("North",topPanel);
		getContentPane().add("Center",listPanel);
		getContentPane().add("South",cPanel);
	}
	
	protected void doAdd()
	{
		ColorEditor ce=new ColorEditor(this,cs.getType());
		ce.setVisible(true);
		((ColorRangeModel)list.getModel()).add(ce.getColor(),ce.getRange());
	}
	
	protected void doEdit()
	{
		int index=list.getSelectedIndex();
		Color oldColor=((ColorRangeModel)list.getModel()).getColor(index);
		double oldRange=((ColorRangeModel)list.getModel()).getRange(index);
		ColorEditor ce=new ColorEditor(this,cs.getType(),oldColor,oldRange);
		ce.setVisible(true);
		((ColorRangeModel)list.getModel()).set(index,ce.getColor(),ce.getRange());
	}
	
	protected void doDelete()
	{
		int index=list.getSelectedIndex();
		((ColorRangeModel)list.getModel()).remove(index);
	}

	void doSave() { }
	void doSaveAs() { }

	void doOpen()
	{
		JFileChooser jfc=new JFileChooser(ColorScheme.COLORS);
		jfc.setFileFilter(new LCDFilter());
		if(jfc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)
		{
			try
			{
				File selectedFile=jfc.getSelectedFile();
				ColorScheme cs=new ColorScheme(selectedFile);
				setColorScheme(cs);
			}
			catch(Exception e) { e.printStackTrace(); }
		}
	}

	void doClose() { }
	
	private class ColorRangeModel extends AbstractListModel
	{
		public ColorRangeModel() { }
		public int getSize() { return(cs.getColorRangeCount()); }

		public Object getElementAt(int index) { return(cs.getColorRange(index)); }
		
		public void add(ColorRange cr)
		{
			cs.addColorRange(cr);
			fireIntervalAdded(this,getSize()-1,getSize()-1);
		}

		public void add(Color c,double r) { add(new ColorRange(c,r)); }
		
		public void set(int index,ColorRange cr)
		{
			cs.setColorRange(index,cr);
			fireContentsChanged(this,index,index);
		}

		public void set(int index,Color c,double r) { set(index,new ColorRange(c,r)); }
		
		public void remove(int index)
		{
			cs.removeColorRange(index);
			fireIntervalRemoved(this,index,index);
		}
		
		public void update() { fireContentsChanged(this,0,getSize()); }
		
		public Color getColor(int index) { return(cs.getColor(index)); }
		public double getRange(int index) { return(cs.getRange(index)); }
		public ColorRange getColorRange(int index) { return(cs.getColorRange(index)); }
	}

	public ColorScheme getColorScheme() { return(cs); }

	public void setColorScheme(ColorScheme cs) 
	{ 
		this.cs=cs;
		preset.setColorScheme(cs);
		ntf.setText(cs.getName());
		dtf.setText(cs.getDescription());
		tcb.setSelectedIndex(cs.getType());
		cdf.setValue(cs.getCycles());
		((ColorRangeModel)list.getModel()).update();
		updateTitle();
	}

	public void setPreset(Preset preset)
	{
		this.preset=preset;
		setColorScheme(preset.getColorScheme());
	}
	
	public void updateTitle() { setTitle("Color scheme: "+cs.getDescription()); }
	
	private class AddAction extends AbstractAction
	{
		public AddAction() { super("Add Color"); }
		public void actionPerformed(ActionEvent e) { doAdd(); }
	}

	private class EditAction extends AbstractAction
	{
		public EditAction() { super("Edit Color"); }
		public void actionPerformed(ActionEvent e) { doEdit(); }
	}

	private class DeleteAction extends AbstractAction
	{
		public DeleteAction() { super("Delete Color"); }
		public void actionPerformed(ActionEvent e) { doDelete(); }
	}

	private class SaveAction extends AbstractAction
	{
		public SaveAction() { super("Save"); }
		public void actionPerformed(ActionEvent e) { doSave(); }
	}

	private class SaveAsAction extends AbstractAction
	{
		public SaveAsAction() { super("Save As..."); }
		public void actionPerformed(ActionEvent e) { doSaveAs(); }
	}

	private class OpenAction extends AbstractAction
	{
		public OpenAction() { super("Open..."); }
		public void actionPerformed(ActionEvent e) { doOpen(); }
	}

	private class CloseAction extends AbstractAction
	{
		public CloseAction() { super("Close"); }
		public void actionPerformed(ActionEvent e) { doClose(); }
	}

	private class LCDFilter extends FileFilter 
	{ 
		public boolean accept(File f) { return(f.isDirectory() || f.getName().endsWith(".lcd")); } 
		public String getDescription() { return("LSystem Preset Documents (*.lcd)"); }
	}
}

