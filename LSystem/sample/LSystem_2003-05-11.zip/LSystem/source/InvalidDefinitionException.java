public class InvalidDefinitionException extends Exception { }
