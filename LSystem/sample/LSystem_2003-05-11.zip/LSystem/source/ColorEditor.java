/*
	Edits a color and its range.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.Keymap;

public class ColorEditor extends JDialog
{
	JPanel range;
	ColorField cf;
	int type;
	
	ColorEditor(Frame parent,int type)
	{
		super(parent,"Add Color",true);

		this.type=type;
		
		JPanel cp=new JPanel(); // content pane
		cp.setLayout(new BorderLayout());
		cp.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		if(type==ColorScheme.TYPE_CONTINUOUS) range=new DoubleField(0);
		else range=new IntegerField(0);

		cf=new ColorField();
		
		cp.add("North",createEditorPanel());
		cp.add("South",createButtonPanel());
		setContentPane(cp);
		pack();
		
		// hitting escape closes this window
		addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent ke) { if(ke.getKeyCode()==KeyEvent.VK_ESCAPE) setVisible(false); } });
		
		int mx=parent.getLocation().x+parent.getSize().width/2-getSize().width/2;
		int my=parent.getLocation().y+parent.getSize().height/2-getSize().height/2;
		setLocation(new Point(mx,my));
	}
	
	ColorEditor(Frame parent,int type,Color color,double range)
	{
		this(parent,type);
		setTitle("Edit Color");

		if(type==ColorScheme.TYPE_CONTINUOUS) ((DoubleField)this.range).setValue(range);
		else ((IntegerField)this.range).setValue((int)range);

		cf.setColor(color);
	}
	
	private JPanel createEditorPanel()
	{
		JPanel ep=new JPanel(); // editor panel
		ep.setLayout(new BorderLayout());
		
		JPanel np=new JPanel(); // name panel (name + "->")
		np.setLayout(new BoxLayout(np,BoxLayout.X_AXIS));
		np.add(new JLabel("Range:"));
		np.add(Box.createHorizontalStrut(10));
		np.add(range);
		np.add(Box.createHorizontalStrut(10));
		np.add(new JLabel("Color:"));
		np.add(Box.createHorizontalStrut(10));
		ep.add("West",np);
		
		ep.add("Center",cf);
		
		return(ep);
	}
	
	private JPanel createButtonPanel()
	{
		JPanel bp=new JPanel();
		bp.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		JButton cancel=new JButton("Cancel");
		cancel.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { setVisible(false); } });
		bp.add(cancel);
		
		JButton ok=new JButton("OK");
		ok.setPreferredSize(cancel.getPreferredSize());
		ok.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { closeRequested(); } });
		getRootPane().setDefaultButton(ok);
		bp.add(ok);
		
		return(bp);
	}
	
	private void closeRequested()
	{
		setVisible(false);
	}
	
	public Color getColor() { return(cf.getColor()); }

	public double getRange()
	{
		double value;
		if(type==ColorScheme.TYPE_CONTINUOUS) value=((DoubleField)range).getValue();
		else value=((IntegerField)range).getValue();
		return(value);
	}

	public ColorRange getColorRange() { return(new ColorRange(getColor(),getRange())); }

/*
	Removes the "enter" keymap from textfields so they go to the OK button.
*/
	static
	{
		JTextField f = new JTextField();
		KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		Keymap map = f.getKeymap();
		map.removeKeyStrokeBinding(enter);
	}

	class ColorField extends JPanel
	{
		Color color;

		ColorField(Color color)
		{
			setColor(color);
			MouseListener ml=new MouseAdapter()
			{
				public void mouseClicked(MouseEvent me)
				{
					if(me.getClickCount()==2)
					{
						Color c=chooseColor();
						if(c!=null) setColor(c);
					}
				}
			};
			addMouseListener(ml);
		}

		ColorField() { this(Color.white); }

		Color chooseColor() { return(JColorChooser.showDialog(this,"Select Color",color)); }

		public Color getColor() { return(color); }
		public void setColor(Color color) { this.color=color; setBackground(color); }

		public Dimension getPreferredSize() { return(new Dimension(32,32)); }
		public Dimension getMinimumSize() { return(new Dimension(10,10)); }
	}
}

