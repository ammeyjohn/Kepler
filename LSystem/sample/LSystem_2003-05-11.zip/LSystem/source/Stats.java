/*
	Does a bucket iteration to predict path lengths.
	"The central observation is that the growth functions of DOL-
	systems are independent of the letter ordering in the productions
	and derived words." -- Prusinkiewicz and Lindenmayer, "TABOP"
*/

import java.util.*;
import java.io.File;

public class Stats
{
	Preset preset;

	Stats(Preset preset)
	{
		this.preset=preset;
	}

	public int getFCount(int iter)
	{
		HashMap ham=makeFullPathMap(iter);
		Object o=ham.get(new Character('F'));
		if(o==null) return(0);
		else return(((Integer)o).intValue());
	}

	public int getFullPathLength(int iter)
	{
		return(sumIntegerMap(makeFullPathMap(iter)));
	}

	HashMap makeFullPathMap(int iter)
	{
		HashMap full=makePathMap(iter);
		HashMap defs=makeDefMap();
		//System.out.println(full);
		//System.out.println(defs);
		Alias def;

		for(int j=0;j<preset.getDefinitionCount();j++)
		{
			def=preset.getDefinition(j);
			for(int k=0;k<def.getValue().length();k++)
				if(full.get(new Character(def.getValue().charAt(k)))==null)
					full.put(new Character(def.getValue().charAt(k)),new Integer(0));
		}

		Iterator i=new HashMap(full).entrySet().iterator();
		while(i.hasNext())
		{
			Character c=(Character)((Map.Entry)i.next()).getKey();
			if(preset.isDefinition(c.charValue()))
			{
				HashMap counts=(HashMap)defs.get(c);
				Iterator t=counts.entrySet().iterator();
				while(t.hasNext())
				{
					Character h=(Character)((Map.Entry)t.next()).getKey();
					int n=((Integer)full.get(h)).intValue();
					n+=((Integer)full.get(c)).intValue()*((Integer)counts.get(h)).intValue();
					full.put(h,new Integer(n));
				}
				full.remove(c);
			}
		}

		return(full);
	}

	public int getPathLength(int iter)
	{
		return(sumIntegerMap(makePathMap(iter)));
	}

	HashMap makePathMap(int iter)
	{
		HashMap uses=makeUseMap();
		HashMap sums=makeAxiomMap(uses);
		HashMap newsums;

		for(int j=1;j<=iter;j++)
		{
			newsums=new HashMap(sums);
			Iterator r=newsums.entrySet().iterator();
			while(r.hasNext())
				newsums.put(((Map.Entry)r.next()).getKey(),new Integer(0));

			Iterator t=sums.entrySet().iterator();
			while(t.hasNext())
			{
				Character name=(Character)((Map.Entry)t.next()).getKey();
				HashMap ham=(HashMap)uses.get(name);
				Iterator i=ham.entrySet().iterator();
				while(i.hasNext())
				{
					Character c=(Character)((Map.Entry)i.next()).getKey();
					int n=((Integer)newsums.get(c)).intValue();
					n+=((Integer)ham.get(c)).intValue()*((Integer)sums.get(name)).intValue();
					newsums.put(c,new Integer(n));
				}
			}
			sums=newsums;
		}

		return(sums);
	}

	int sumIntegerMap(HashMap ham)
	{
		Iterator i=ham.entrySet().iterator();
		int sum=0;

		while(i.hasNext())
			sum+=((Integer)((Map.Entry)i.next()).getValue()).intValue();

		return(sum);
	}

	HashMap makeAxiomMap(HashMap uses)
	{
		HashMap ham=new HashMap(uses.size());
		String axiom=preset.getAxiom();

		Iterator i=uses.entrySet().iterator();
		while(i.hasNext())
			ham.put(((Map.Entry)i.next()).getKey(),new Integer(0));

		for(int j=0;j<axiom.length();j++)
		{
			int n=((Integer)ham.get(new Character(axiom.charAt(j)))).intValue();
			ham.put(new Character(axiom.charAt(j)),new Integer(n+1));
		}

		return(ham);
	}

	HashMap makeUseMap()
	{
		HashMap ham=new HashMap(preset.getRuleCount());
		String allused="";
		HashMap counts;
		Alias rule;

		for(int j=0;j<preset.getRuleCount();j++)
		{
			rule=preset.getRule(j);
			for(int k=0;k<rule.getValue().length();k++)
				if(allused.indexOf(rule.getValue().charAt(k))==-1)
					allused+=rule.getValue().charAt(k);
		}

		for(int j=0;j<preset.getRuleCount();j++)
		{
			counts=new HashMap(allused.length());
			for(int k=0;k<allused.length();k++)
				counts.put(new Character(allused.charAt(k)),new Integer(0));

			rule=preset.getRule(j);
			for(int k=0;k<rule.getValue().length();k++)
			{
				int n=((Integer)counts.get(new Character(rule.getValue().charAt(k)))).intValue();
				counts.put(new Character(rule.getValue().charAt(k)),new Integer(n+1));
			}

			ham.put(new Character(rule.getName()),counts);
		}

		for(int j=0;j<allused.length();j++)
		{
			if(!preset.isRule(allused.charAt(j)))
			{
				HashMap h=new HashMap();
				for(int k=0;k<allused.length();k++)
				{
					if(allused.charAt(k)==allused.charAt(j)) h.put(new Character(allused.charAt(k)),new Integer(1));
					else h.put(new Character(allused.charAt(k)),new Integer(0));
				}
				ham.put(new Character(allused.charAt(j)),h);
			}
		}

		return(ham);
	}

	HashMap makeDefMap()
	{
		HashMap ham=new HashMap(preset.getDefinitionCount());
		HashMap counts;
		Alias def;

		for(int j=0;j<preset.getDefinitionCount();j++)
		{
			def=preset.getDefinition(j);
			counts=new HashMap();
			for(int k=0;k<def.getValue().length();k++)
			{
				Character c=new Character(def.getValue().charAt(k));
				if(counts.get(c)==null) counts.put(c,new Integer(1));
				else
				{
					int n=((Integer)counts.get(c)).intValue();
					counts.put(c,new Integer(n+1));
				}
			}
			ham.put(new Character(def.getName()),counts);
		}

		return(ham);
	}

	public static void main(String[] args)
	{
		try
		{
			Preset preset=new Preset(new File(Preset.PRESETS+args[0]+".lsd"));
			Stats stats=new Stats(preset);
			int iter=Integer.parseInt(args[1]);
			System.out.println("use map:\t"+stats.makeUseMap());
			System.out.println("def map:\t"+stats.makeDefMap());
			System.out.println("axiom map:\t"+stats.makeAxiomMap(stats.makeUseMap()));
			System.out.println("path length:\t"+stats.getPathLength(iter));
			System.out.println("path map:\t"+stats.makePathMap(iter));
			System.out.println("full length:\t"+stats.getFullPathLength(iter));
			System.out.println("full map:\t"+stats.makePathMap(iter));
		}
		catch(Exception e) { e.printStackTrace(); }
	}
}

