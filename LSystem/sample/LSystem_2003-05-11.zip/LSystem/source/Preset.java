/*
	Store defining information for an L-System.
*/

import java.io.*;
import java.util.ArrayList;
import javax.swing.event.*;

public class Preset extends Object
{
	static final String builtins="Ff+-|&[]()^_<>/\\{}.`'wW!@";  // Built-in tokens

	public static final String PATHS="paths/";      // Location of paths
	public static final String PRESETS="presets/";  // Location of presets
	public static final String IMAGES="images/";    // Location of images

	String name;            // Name of this preset
	String description;     // Short description of preset
	ColorScheme cs;         // Color scheme for drawing
	ArrayList rules;        // List of rules
	ArrayList definitions;  // List of definitions
	String axiom;           // Axiom (initial rule)
	double angle;           // Angle to turn by
	double angleIncrement;  // Amount to increment angle by
	double angleScale;      // Amount to scale angle by
	double width;           // Width of lines
	double widthIncrement;  // Amount to increment width by
	double widthScale;      // Amount to scale width by
	double length;          // Length of lines
	double lengthIncrement; // Amount to increment length by
	double lengthScale;     // Amount to scale length by

	public static final String NAME_DEFAULT="untitled";
	public static final String DESCRIPTION_DEFAULT="Untiled Preset";
	public static final String COLOR_SCHEME_DEFAULT="white";
	public static final String AXIOM_DEFAULT="";
	
	public static final double ANGLE_MIN=0;
	public static final double ANGLE_MAX=360;
	public static final double ANGLE_DEFAULT=0;
	
	public static final double ANGLE_INCREMENT_MIN=-360;
	public static final double ANGLE_INCREMENT_MAX=360;
	public static final double ANGLE_INCREMENT_DEFAULT=1;

	public static final double ANGLE_SCALE_MIN=-100;
	public static final double ANGLE_SCALE_MAX=100;
	public static final double ANGLE_SCALE_DEFAULT=2;
	
	public static final double WIDTH_MIN=0;
	public static final double WIDTH_MAX=500;
	public static final double WIDTH_DEFAULT=1;
	
	public static final double WIDTH_INCREMENT_MIN=-100;
	public static final double WIDTH_INCREMENT_MAX=100;
	public static final double WIDTH_INCREMENT_DEFAULT=1;
	
	public static final double WIDTH_SCALE_MIN=-100;
	public static final double WIDTH_SCALE_MAX=100;
	public static final double WIDTH_SCALE_DEFAULT=2;
	
	public static final double LENGTH_MIN=-1000;
	public static final double LENGTH_MAX=1000;
	public static final double LENGTH_DEFAULT=1;
	
	public static final double LENGTH_INCREMENT_MIN=-10;
	public static final double LENGTH_INCREMENT_MAX=10;
	public static final double LENGTH_INCREMENT_DEFAULT=0.1;
	
	public static final double LENGTH_SCALE_MIN=-100;
	public static final double LENGTH_SCALE_MAX=100;
	public static final double LENGTH_SCALE_DEFAULT=1.1;
	
	protected boolean saved;

	EventListenerList listenerList;

/*
	Create a new information container.
*/
	public Preset()
	{
		name=NAME_DEFAULT;
		description=DESCRIPTION_DEFAULT;
		try { setColorScheme(new ColorScheme(new File("colors/white.lcd"))); }
		catch(Exception frink) { frink.printStackTrace(); }
		rules=new ArrayList();
		definitions=new ArrayList();
		axiom=AXIOM_DEFAULT;
		angle=ANGLE_DEFAULT;
		angleIncrement=ANGLE_INCREMENT_DEFAULT;
		angleScale=ANGLE_SCALE_DEFAULT;
		width=WIDTH_DEFAULT;
		widthIncrement=WIDTH_INCREMENT_DEFAULT;
		widthScale=WIDTH_SCALE_DEFAULT;
		length=LENGTH_DEFAULT;
		lengthIncrement=LENGTH_INCREMENT_DEFAULT;
		lengthScale=LENGTH_SCALE_DEFAULT;

		listenerList=new EventListenerList();
	}

/*
	Makes sure that all of the characters in a string have some kind of definition.
*/
	public boolean allDefined(String s)
	{
		for(int j=0;j<s.length();j++) if(!isDefined(s.charAt(j))) return(false);
		return(true);
	}

/*
	Checks whether a character is something important.
*/
	public boolean isDefined(char c) { return(isBuiltin(c) || isDefinition(c)); }
	public boolean isRule(char c) { return(getRule(c)!=null); }
	public boolean isDefinition(char c) { return(getDefinition(c)!=null); }
	public boolean isBuiltin(char c) { return(builtins.indexOf(c)!=-1); }

	// add(Alias)
	public void addAlias(Alias a,int type)
	{
		if(type==Alias.RULE) addRule(a);
		else if(type==Alias.DEFINITION) addDefinition(a);
		else throw(new IllegalTypeException());
	}

	public void addRule(Alias a) { rules.add(a); fireChangeEvent(PresetChangeEvent.RULES); }
	public void addDefinition(Alias a) { definitions.add(a); fireChangeEvent(PresetChangeEvent.DEFINITIONS); }
	
	// set(index,Alias)
	public void setAlias(int index,Alias a,int type)
	{
		if(type==Alias.RULE) setRule(index,a);
		else if(type==Alias.DEFINITION) setDefinition(index,a);
		else throw(new IllegalTypeException());
	}

	public void setRule(int index,Alias a) { rules.set(index,a); fireChangeEvent(PresetChangeEvent.RULES); }
	public void setDefinition(int index,Alias a) { definitions.set(index,a); fireChangeEvent(PresetChangeEvent.DEFINITIONS); }

	// remove(index)
	public void removeAlias(int index,int type)
	{
		if(type==Alias.RULE) removeRule(index);
		else if(type==Alias.DEFINITION) removeDefinition(index);
		else throw(new IllegalTypeException());
	}

	public void removeRule(int index) { rules.remove(index); fireChangeEvent(PresetChangeEvent.RULES); }
	public void removeDefinition(int index) { definitions.remove(index); fireChangeEvent(PresetChangeEvent.DEFINITIONS); }

	// get()
	public ArrayList getAliases(int type)
	{
		if(type==Alias.RULE) return(getRules());
		else if(type==Alias.DEFINITION) return(getDefinitions());
		else throw(new IllegalTypeException()); 
	}

	public ArrayList getRules() { return(rules); }
	public ArrayList getDefinitions() { return(definitions); }

	// getCount()
	public int getAliasCount(int type)
	{
		if(type==Alias.RULE) return(getRuleCount());
		else if(type==Alias.DEFINITION) return(getDefinitionCount());
		else throw(new IllegalTypeException());
	}

	public int getRuleCount() { return(rules.size()); }
	public int getDefinitionCount() { return(definitions.size()); }
	
	// get(index)
	public Alias getAlias(int index,int type)
	{
		if(type==Alias.RULE) return(getRule(index));
		else if(type==Alias.DEFINITION) return(getDefinition(index));
		else throw(new IllegalTypeException());
	}

	public Alias getRule(int index) { return((Alias)rules.get(index)); }
	public Alias getDefinition(int index) { return((Alias)definitions.get(index)); }
	
	// get(name)
	public Alias getAlias(char name,int type)
	{
		if(type==Alias.RULE) return(getRule(name));
		else if(type==Alias.DEFINITION) return(getDefinition(name));
		else throw(new IllegalTypeException());
	}

	public Alias getRule(char c)
	{
		int index=rules.indexOf(new Alias(c));
		if(index==-1) return(null);
		else return(getRule(index));
	}

	public Alias getDefinition(char c)
	{
		int index=definitions.indexOf(new Alias(c));
		if(index==-1) return(null);
		else return(getDefinition(index));
	}

/*
	Axiom accessors
*/
	public String getAxiom() { return(axiom); }

	public void setAxiom(String axiom) throws InvalidAxiomException
	{
		if(allDefined(axiom)) this.axiom=axiom;
		else throw(new InvalidAxiomException());
		fireChangeEvent(PresetChangeEvent.AXIOM);
	}

/*
	Parameter accessors
*/
	public double getAngle() { return(angle); }

	public void setAngle(double angle) throws InvalidAngleException
	{
		if((angle>=0)&&(angle<=360)) this.angle=angle;
		else throw(new InvalidAngleException());
		fireChangeEvent(PresetChangeEvent.ANGLE);
	}

	public double getAngleScale() { return(angleScale); }
	public double getAngleIncrement() { return(angleIncrement); }
	public double getWidth() { return(width); }
	public double getWidthIncrement() { return(widthIncrement); }
	public double getWidthScale() { return(widthScale); }
	public double getLength() { return(length); }
	public double getLengthIncrement() { return(lengthIncrement); }
	public double getLengthScale() { return(lengthScale); }
	
	public void setAngleScale(double angleScale) { this.angleScale=angleScale; fireChangeEvent(PresetChangeEvent.ANGLE_SCALE); }
	public void setAngleIncrement(double angleIncrement) { this.angleIncrement=angleIncrement; fireChangeEvent(PresetChangeEvent.ANGLE_INCREMENT); }
	public void setWidth(double width) { this.width=width; fireChangeEvent(PresetChangeEvent.WIDTH); }
	public void setWidthIncrement(double widthIncrement) { this.widthIncrement=widthIncrement; fireChangeEvent(PresetChangeEvent.WIDTH_INCREMENT); }
	public void setWidthScale(double widthScale) { this.widthScale=widthScale; fireChangeEvent(PresetChangeEvent.WIDTH_SCALE); }
	public void setLength(double length) { this.length=length; fireChangeEvent(PresetChangeEvent.LENGTH); }
	public void setLengthIncrement(double lengthIncrement) { this.lengthIncrement=lengthIncrement; fireChangeEvent(PresetChangeEvent.LENGTH_INCREMENT); }
	public void setLengthScale(double lengthScale) { this.lengthScale=lengthScale; fireChangeEvent(PresetChangeEvent.LENGTH_SCALE); }

	public boolean isSaved() { return(saved); }
	public void setSaved(boolean saved) { this.saved=saved; }

	public ColorScheme getColorScheme() { return(cs); }

	public void setColorScheme(ColorScheme csc)
	{
		this.cs=csc;
		cs.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent ce)
			{
				cs=(ColorScheme)ce.getSource();
				System.out.println("fam!\n"+cs);
				fireChangeEvent(PresetChangeEvent.COLOR);
			}
		});
		//fireChangeEvent(PresetChangeEvent.COLOR);
	}

/*
	Name accessors
*/
	public String getName()
	{
		if(name==null) setName("untitled");
		return(name);
	}

	public void setName(String name) { this.name=name; }

	public String getDescription()
	{
		if(description==null) setDescription("Untitled Preset");
		return(description);
	}

	public void setDescription(String description) { this.description=description; fireChangeEvent(PresetChangeEvent.DESCRIPTION); }

	public Preset(File file) throws IOException,FileFormatException,InvalidRuleException,InvalidDefinitionException,InvalidAngleException,InvalidAxiomException
	{
		this();
		StreamTokenizer st=new StreamTokenizer(new InputStreamReader(new FileInputStream(file)));

		st.quoteChar('\"');
		st.commentChar('#');
		st.ordinaryChar('-');   // No es bueno! Un numero negativo?
		st.wordChars('[','['); st.wordChars(']',']');
		st.wordChars('{','{'); st.wordChars('}','}');
		st.wordChars('(','('); st.wordChars(')',')');
		st.wordChars('<','<'); st.wordChars('>','>');
		st.wordChars('&','&'); st.wordChars('|','|');
		st.wordChars('-','-'); st.wordChars('+','+');
		st.wordChars('/','/'); st.wordChars('\\','\\');
		st.wordChars('`','`'); st.wordChars('\'','\'');
        st.wordChars('^','^'); st.wordChars('_','_');
        st.wordChars('!','!'); st.wordChars('@','@');
        st.wordChars('w','w'); st.wordChars('W','W');
		st.wordChars(':',':');

		while(st.nextToken()!=StreamTokenizer.TT_EOF)
		{
			if(st.ttype==StreamTokenizer.TT_WORD)
			{
				if(st.sval.equals("Definitions:"))
				{
					st.nextToken();
					if(!st.sval.equals("{")) throw(new FileFormatException());
					else
					{
						st.nextToken();

						while(!st.sval.equals("}"))
						{
							Alias def=new Alias();
							def.setName(st.sval.charAt(0));
							st.nextToken();
							st.nextToken();
							def.setValue(st.sval);
							addDefinition(def);
							st.nextToken();
						}
					}
				}
				else if(st.sval.equals("Rules:"))
				{
					st.nextToken();
					if(!st.sval.equals("{")) throw(new FileFormatException());
					else
					{
						st.nextToken();

						while(!st.sval.equals("}"))
						{
							Alias rule=new Alias();
							rule.setName(st.sval.charAt(0));
							st.nextToken();
							st.nextToken();
							rule.setValue(st.sval);
							addRule(rule);
							st.nextToken();
						}
					}
				}
				else if(st.sval.equals("Angle:"))
				{
					st.nextToken();
					setAngle(st.nval);
				}
				else if(st.sval.equals("AngleIncrement:"))
				{
					st.nextToken();
					setAngleIncrement(st.nval);
				}
				else if(st.sval.equals("AngleScale:"))
				{
					st.nextToken();
					setAngleScale(st.nval);
				}
				else if(st.sval.equals("Width:"))
				{
					st.nextToken();
					setWidth(st.nval);
				}
				else if(st.sval.equals("WidthIncrement:"))
				{
					st.nextToken();
					setWidthIncrement(st.nval);
				}
				else if(st.sval.equals("WidthScale:"))
				{
					st.nextToken();
					setWidthScale(st.nval);
				}
				else if(st.sval.equals("Length:"))
				{
					st.nextToken();
					setLength(st.nval);
				}
				else if(st.sval.equals("LengthIncrement:"))
				{
					st.nextToken();
					setLengthIncrement(st.nval);
				}
				else if(st.sval.equals("LengthScale:"))
				{
					st.nextToken();
					setLengthScale(st.nval);
				}
				else if(st.sval.equals("Description:"))
				{
					st.nextToken();
					if((st.ttype!=StreamTokenizer.TT_WORD)&&(st.ttype!='\"')) throw(new FileFormatException());
					else setDescription(st.sval);
				}
				else if(st.sval.equals("Name:"))
				{
					st.nextToken();
					if((st.ttype!=StreamTokenizer.TT_WORD)&&(st.ttype!='\"')) throw(new FileFormatException());
					else setName(st.sval);
				}
				else if(st.sval.equals("Axiom:"))
				{
					st.nextToken();
					setAxiom(st.sval);
				}
				else if(st.sval.equals("Color:"))
				{
					st.nextToken();
					String name=ColorScheme.COLORS+st.sval+ColorScheme.COLOR_SCHEME_SUFFIX;
					setColorScheme(new ColorScheme(new File(name)));
				}
				else throw(new FileFormatException());
			}
			else throw(new FileFormatException());
		}
	}

/*
	Saves a freakin' set.
*/
	public void savePreset(File file) throws IOException
	{
		DataOutputStream dos=new DataOutputStream(new FileOutputStream(file));
		dos.writeBytes("Name:\t"+getName()+"\n");
		dos.writeBytes("Description:\t\""+getDescription()+"\"\n");
		dos.writeBytes("Color:\t"+getColorScheme().getName()+"\n");
		if(getDefinitions().size()!=0)
		{
			dos.writeBytes("Definitions:\n{\n");
			for(int j=0;j<getDefinitions().size();j++) dos.writeBytes("\t"+getDefinitions().get(j).toString()+"\n");
			dos.writeBytes("}\n");
		}

        // Only write out parameters that differ from the default.
		if(getAngle()!=ANGLE_DEFAULT)
            dos.writeBytes("Angle:\t"+getAngle()+"\n");
		if(getAngleIncrement()!=ANGLE_INCREMENT_DEFAULT)
            dos.writeBytes("AngleIncrement:\t"+getAngleIncrement()+"\n");
		if(getAngleScale()!=ANGLE_SCALE_DEFAULT)
            dos.writeBytes("AngleScale:\t"+getAngleScale()+"\n");
		if(getWidth()!=WIDTH_DEFAULT)
            dos.writeBytes("Width:\t"+getWidth()+"\n");
		if(getWidthIncrement()!=WIDTH_INCREMENT_DEFAULT)
            dos.writeBytes("WidthIncrement:\t"+getWidthIncrement()+"\n");
		if(getWidthScale()!=WIDTH_SCALE_DEFAULT)
            dos.writeBytes("WidthScale:\t"+getWidthScale()+"\n");
		if(getLength()!=LENGTH_DEFAULT)
            dos.writeBytes("Length:\t"+getLength()+"\n");
		if(getLengthIncrement()!=LENGTH_INCREMENT_DEFAULT)
            dos.writeBytes("LengthIncrement:\t"+getLengthIncrement()+"\n");
		if(getLengthScale()!=LENGTH_SCALE_DEFAULT)
            dos.writeBytes("LengthScale:\t"+getLengthScale()+"\n");

		dos.writeBytes("Axiom:\t"+getAxiom()+"\n");
		dos.writeBytes("Rules:\n{\n");
		for(int j=0;j<getRules().size();j++)
            dos.writeBytes("\t"+getRules().get(j).toString()+"\n");
		dos.writeBytes("}\n");
        dos.flush();
        dos.close();
	}

/*
	Returns a String representation of this Preset.
*/
	public String toString()
	{
		return(""+getDefinitions()+"\n"+getRules()+"\n"+getAxiom()+"\n"+getAngle());
	}
	
/*
	Makes this class a source of ChangeEvents (specifically, PresetChangeEvents).
*/
	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	void fireChangeEvent(Object source,int type)
	{
		ChangeEvent ce=new PresetChangeEvent(source,type);
		Object[] listeners=listenerList.getListenerList();
		for(int j=listeners.length-2;j>=0;j-=2) 
			if(listeners[j]==ChangeListener.class) 
				((ChangeListener)listeners[j+1]).stateChanged(ce);
	}
	void fireChangeEvent(int type) { fireChangeEvent(this,type); }
}

