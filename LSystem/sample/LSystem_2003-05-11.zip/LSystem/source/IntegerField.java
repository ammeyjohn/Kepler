/*
	Text field for bounded integers (restrictions on min and max) and increment/decrement buttons.
	Ensures valid entries and exposes getValue() and setValue(int).
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class IntegerField extends JPanel
{
	protected final SmartTextField tf;
	protected final JScrollBar sb;
	
	protected int value;
	protected int minimum;
	protected int maximum;
	protected int increment;
	protected int columns;
	
	protected final int defaultValue;
	
	public IntegerField(int value,int minimum,int maximum,int increment,int columns)
	{
		this.value=value;
		this.minimum=minimum;
		this.maximum=maximum;
		this.increment=increment;
		this.columns=columns;
		defaultValue=value;
		setLayout(new BorderLayout());
		
		tf=new SmartTextField(Integer.toString(getValue()),getColumns());
		tf.addChangeListener(new ChangeListener() { public void stateChanged(ChangeEvent ce) { validateText(); } });
		add("Center",tf);
		
		sb=new JScrollBar(JScrollBar.VERTICAL,getMaximum()-getValue(),0,getMinimum(),getMaximum());
		sb.setBlockIncrement(getIncrement());
		sb.setUnitIncrement(getIncrement());
		sb.setPreferredSize(new Dimension(sb.getPreferredSize().width,tf.getPreferredSize().height));
		sb.addAdjustmentListener(new AdjustmentListener() { 
			public void adjustmentValueChanged(AdjustmentEvent e) { setValue(sb.getMaximum()-e.getValue()); } 
		});
		add("East",sb);
		
	}

	public IntegerField(int value,int minimum,int maximum,int increments) { this(value,minimum,maximum,increments,5); }
	public IntegerField(int value,int minimum,int maximum) { this(value,minimum,maximum,1,5); }
	public IntegerField(int value) { this(value,0,100,1,5); }
	
	protected void validateText()
	{
		String text=tf.getText();
		if(text.equals("")) text=Integer.toString(defaultValue);
		
		try 
		{ 
			int value=Integer.parseInt(text); 
			if(value<getMinimum()) value=getMinimum();
			if(value>getMaximum()) value=getMaximum();
			setValue(value);
		}
		catch(NumberFormatException e) 
		{
			displayError("You must enter a valid integer in the text field");
		}
	}

	public int getValue() { return(value); }
	public int getMinimum() { return(minimum); }
	public int getMaximum() { return(maximum); }
	public int getIncrement() { return(increment); }
	public int getColumns() { return(columns); }
	
	public void setValue(int value) 
	{ 
		if(this.value!=value)
		{
			this.value=value; 
			sb.setValue(getMaximum()-value); 
			tf.setText(Integer.toString(value)); 
			fireChangeEvent(); 
		}
	}
	public void setMinimum(int minimum) { this.minimum=minimum; sb.setMinimum(minimum); }
	public void setMaximum(int maximum) { this.maximum=maximum; sb.setMaximum(maximum); }
	public void setIncrement(int increment) { this.increment=increment; sb.setUnitIncrement(increment); sb.setBlockIncrement(increment); }
	public void setColumns(int columns) { this.columns=columns; tf.setColumns(columns); }
	
/*
	Returns the number of character columns needed to display the given integer (e.g. 999->3, 1000->4).
*/
	public static int getTextLength(int n) { return(1+(int)Math.floor(Math.log(n)/Math.log(10))); }
	
/*
	Passes the error message along to the SmartTextField inside this IntegerField.
*/
	public void displayError(String error) { tf.displayError(error); }
	
/*
	Standard code to make this class a source of ChangeEvents.
*/
	protected EventListenerList listenerList=new EventListenerList();
	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	protected void fireChangeEvent()
	{
		ChangeEvent ce=new ChangeEvent(this);
		Object[] listeners=listenerList.getListenerList();
		for(int i=listeners.length-2;i>=0;i-=2) 
			if(listeners[i]==ChangeListener.class) 
				((ChangeListener)listeners[i+1]).stateChanged(ce);
	}
}
