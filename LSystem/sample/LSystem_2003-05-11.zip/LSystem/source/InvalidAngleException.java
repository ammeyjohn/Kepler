public class InvalidAngleException extends Exception { }
