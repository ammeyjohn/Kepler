/*
	The root of the LSystem GUI. Shows the rendered image with controls to manipulate parameters.
*/

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.print.*;
import java.io.File;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.event.*;
import javax.swing.filechooser.FileFilter;

public class Presenter extends JFrame
{
	protected Render render; // Data model driving the current LSystem

	protected static final String TITLE="LSystem"; // Title of this window

	// Components for the control panel
	protected final BufferedImagePanel imagePanel;
	protected final IntegerField iteration,width,height;
	protected final JProgressBar progress;
	protected final JButton cancel;

	// Other windows
	protected final AliasFrame rules,definitions;
	protected final ParameterFrame parameters;
	protected final ColorFrame cf;
	protected final PathFrame path;
	protected final SymbolFrame symbols;

	// Swap, invert, and preserve checkboxes
	protected final JCheckBoxMenuItem swap,invert,preserve;

	// Info for saving presets
	private File savedLocation;

	private boolean preserveAspectRatio; // Whether to constrain image aspect ratio

	private int fMax; // Max number of Fs in a given render

/*
	Constructs a new l-system presenter.
*/
	public Presenter(Render render)
	{
		super(TITLE);
		PathManager.clearPaths();

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		imagePanel=new BufferedImagePanel(render.getImage());
		imagePanel.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) { if(me.getClickCount()==2) pack(); }
		});

		iteration=new IntegerField(render.getIteration(),0,Integer.MAX_VALUE,1,3);
		iteration.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce) { getRender().setIteration(iteration.getValue()); }
		});

		width=new IntegerField(render.getWidth(),0,Integer.MAX_VALUE,50,4);
		width.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce) { setWidth(width.getValue()); }
		});

		height=new IntegerField(render.getHeight(),0,Integer.MAX_VALUE,50,4);
		height.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce) { setHeight(height.getValue()); }
		});

		progress=new JProgressBar();
		progress.setStringPainted(true);
		cancel=new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) { getRender().interruptRender(); reset(); }
		});

		rules=new AliasFrame(render.getPreset(),Alias.RULE);
		definitions=new AliasFrame(render.getPreset(),Alias.DEFINITION);
		parameters=new ParameterFrame(render.getPreset());
		cf=new ColorFrame(render.getPreset().getColorScheme(),render.getPreset());
		path=new PathFrame();
		symbols=new SymbolFrame();

		swap=new JCheckBoxMenuItem("Swap X & Y");
		swap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae)
			{
				getRender().setSwapped(swap.isSelected());
				getProgressBar().setString("Swapping X & Y...");
				getImagePanel().setImage(getRender().getImage());
				getProgressBar().setString("Ready.");
			}
		});

		invert=new JCheckBoxMenuItem("Invert Background");
		invert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae)
			{
				getRender().setInverted(invert.isSelected());
				getProgressBar().setString("Inverting Background...");
				getImagePanel().setImage(getRender().getImage());
				getProgressBar().setString("Ready.");
			}
		});

		preserveAspectRatio=true;
		preserve=new JCheckBoxMenuItem("Preserve Aspect Ratio",preserveAspectRatio);
		preserve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) { setPreserveAspectRatio(preserve.isSelected()); }
		});

		addWindowListener(new WindowAdapter()
		{
			//public void windowActivated(WindowEvent we) { show(); }
			public void windowClosing(WindowEvent we) { doQuit(); }
		});

		addComponentListener(new ComponentAdapter() {
			//public void componentResized(ComponentEvent e) { positionWindows(); }
			//public void componentMoved(ComponentEvent e) { positionWindows(); }
		});

		setJMenuBar(createMenuBar());

		JPanel contentPane=new JPanel();
		contentPane.setLayout(new BorderLayout());
		contentPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		contentPane.add("Center",new JScrollPane(imagePanel));
		contentPane.add("South",createInfoPanel());
		setContentPane(contentPane);

		setRender(render);

		pack();
		setLocation(200,50);

	}

    private JMenuBar createMenuBar()
    {
        JMenuBar menuBar=new JMenuBar();

        JMenu file=new JMenu("File");
        file.add(new NewAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,KeyEvent.CTRL_MASK));
        file.add(new OpenAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,KeyEvent.CTRL_MASK));
        file.addSeparator();
        file.add(new SaveAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,KeyEvent.CTRL_MASK));
        file.add(new SaveAsAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,KeyEvent.SHIFT_MASK|KeyEvent.CTRL_MASK));
		file.add(new RevertAction());
        file.addSeparator();
		file.add(new SaveImageAsAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,KeyEvent.CTRL_MASK));
		file.addSeparator();
        file.add(new PrintAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,KeyEvent.CTRL_MASK));
        file.addSeparator();
        file.add(new QuitAction()).setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,KeyEvent.CTRL_MASK));
        menuBar.add(file);

        JMenu view=new JMenu("View");
        view.add(swap);
        view.add(invert);
		view.addSeparator();
		view.add(preserve);
        menuBar.add(view);

		JMenu window=new JMenu("Window");
        window.add(new FrameToggler(parameters,"Parameters"));
        window.add(new FrameToggler(rules,"Rules"));
        window.add(new FrameToggler(definitions,"Definitions"));
        window.add(new FrameToggler(cf,"Color Scheme"));
        window.addSeparator();
        window.add(new FrameToggler(symbols,"Symbol List"));
		window.add(new FrameToggler(path,"Path"));
		menuBar.add(window);

		JMenu help=new JMenu("Help");
		help.add(new AboutAction());
		//menuBar.setHelpMenu(help); // not implemented
		menuBar.add(help);

        return(menuBar);
    }

	private JPanel createInfoPanel()
	{
		JPanel infoPanel=new JPanel();
		infoPanel.setLayout(new BoxLayout(infoPanel,BoxLayout.Y_AXIS));
		infoPanel.add(Box.createVerticalStrut(10));
		infoPanel.add(createControlPanel());
		infoPanel.add(Box.createVerticalStrut(10));
		infoPanel.add(createProgressPanel());

		return(infoPanel);
	}

	private JPanel createControlPanel()
	{
		JPanel controlPanel=new JPanel(new BorderLayout());
		controlPanel.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));

		Box iterationPanel=new Box(BoxLayout.Y_AXIS);
		iterationPanel.add(new JLabel("Iteration",JLabel.CENTER));
		iterationPanel.add(iteration);
		controlPanel.add("West",iterationPanel);

		controlPanel.add("Center",Box.createHorizontalStrut(20));

		Box sizePanel=new Box(BoxLayout.X_AXIS);

		Box widthPanel=new Box(BoxLayout.Y_AXIS);
		widthPanel.add(new JLabel("Width",JLabel.CENTER));
		widthPanel.add(width);
		sizePanel.add(widthPanel);

		sizePanel.add(Box.createHorizontalStrut(10));

		Box heightPanel=new Box(BoxLayout.Y_AXIS);
		heightPanel.add(new JLabel("Height",JLabel.CENTER));
		heightPanel.add(height);
		sizePanel.add(heightPanel);

		controlPanel.add("East",sizePanel);

		return(controlPanel);
	}

	private JPanel createProgressPanel()
	{
		JPanel progressPanel=new JPanel(new BorderLayout());
		progressPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(),"Progress"));
		progressPanel.add("Center",progress);
		Box cancelPanel=new Box(BoxLayout.X_AXIS);
		cancelPanel.add(Box.createHorizontalStrut(10));
		cancelPanel.add(cancel);
		progressPanel.add("East",cancelPanel);

		return(progressPanel);
	}

	public Render getRender() { return(render); }
	public Preset getPreset() { return(getRender().getPreset()); }

	public BufferedImagePanel getImagePanel() { return(imagePanel); }
	public IntegerField getIterationField() { return(iteration); }
	public IntegerField getWidthField() { return(width); }
	public IntegerField getHeightField() { return(height); }
	public JCheckBoxMenuItem getSwapBox() { return(swap); }
	public JCheckBoxMenuItem getInvertBox() { return(invert); }
	public JProgressBar getProgressBar() { return(progress); }
	public JButton getCancelButton() { return(cancel); }

	public ParameterFrame getParameterFrame() { return(parameters); }
	public AliasFrame getRuleFrame() { return(rules); }
	public AliasFrame getDefinitionFrame() { return(definitions); }
	public PathFrame getPathFrame() { return(path); }

	public boolean isSaved() { return(getPreset().isSaved()); }
	public File getSavedLocation() { return(savedLocation); }

	public boolean isPreserveAspectRatio() { return(preserveAspectRatio); }

	public void setRender(Render render)
	{
		this.render=render;
		render.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce)
			{
				if(ce instanceof PresetChangeEvent)
				{
					PresetChangeEvent pce=(PresetChangeEvent)ce;

					if(pce.getType()==PresetChangeEvent.DESCRIPTION)
					{
						updateTitle();
						getRuleFrame().updateTitle();
						getDefinitionFrame().updateTitle();
						getParameterFrame().updateTitle();
					}
					else updateImage(pce.getType()==PresetChangeEvent.AXIOM || pce.getType()==PresetChangeEvent.RULES || pce.getType()==PresetChangeEvent.DEFINITIONS);

					setSaved(false);
				}
				else if(ce.getSource() instanceof Factory)
				{
					if(getProgressBar().getString()!=null) getProgressBar().setString(null);
					getProgressBar().setValue(getRender().getFCount());
					getImagePanel().setImage(getRender().getImage());
					if(getRender().getFCount()==fMax) reset();
				}
				else if(ce.getSource() instanceof Render)
					updateImage(false);
			}
		});

		getIterationField().setValue(render.getIteration());
		getWidthField().setValue(render.getWidth());
		getHeightField().setValue(render.getHeight());
		getSwapBox().setSelected(render.isSwapped());
		getInvertBox().setSelected(render.isInverted());

		setPreset(render.getPreset());
	}
	public void setPreset(Preset preset)
	{
		getRender().setPreset(preset);
		getParameterFrame().setPreset(preset);
		getRuleFrame().setPreset(preset);
		getDefinitionFrame().setPreset(preset);
		getPathFrame().setPath(null);
		getImagePanel().setImage(getRender().getImage());
		updateTitle();
		setSaved(true); // presets start saved
		//updateImage(false); // do the 0th iteration
	}

	public void updateTitle() { setTitle(TITLE+": "+getPreset().getDescription()); }

	public void setWidth(int width)
	{
		if(isPreserveAspectRatio())
		{
			double aspectRatio=(double)width/getRender().getWidth();
			height.setValue((int)(getRender().getHeight()*aspectRatio));
			getRender().setSize(width,height.getValue());
		}
		else getRender().setWidth(width);
	}

	public void setHeight(int height)
	{
		if(isPreserveAspectRatio())
		{
			double aspectRatio=(double)height/getRender().getHeight();
			width.setValue((int)(getRender().getWidth()*aspectRatio));
			getRender().setSize(width.getValue(),height);
		}
		else getRender().setHeight(height);;
	}

	public void setSaved(boolean saved)
	{
		getPreset().setSaved(saved);
		String saveMark=(saved?"":"*");
		setTitle(TITLE+": "+getPreset().getDescription()+" "+saveMark);
	}

	public void setPreserveAspectRatio(boolean preserveAspectRatio) { this.preserveAspectRatio=preserveAspectRatio; }

	public void setSavedLocation(File savedLocation) { this.savedLocation=savedLocation; }

	private void updateImage(boolean makePath)
	{
		setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		getCancelButton().setEnabled(true);
		fMax=new Stats(getPreset()).getFCount(getRender().getIteration());
		getProgressBar().setMaximum(fMax);
		getProgressBar().setString("Calculating Path...");
		getRender().startRender(makePath);
	}

	protected void reset()
	{
		if(isSaved()) PathManager.savePaths(getPreset().getName());

		getProgressBar().setValue(0);
		getProgressBar().setString("Ready.");
		getCancelButton().setEnabled(false);
		setCursor(Cursor.getDefaultCursor());

		if(!getPreset().getName().equals("untitled") && getRender().getIteration()>0)
			getPathFrame().setPath(PathManager.loadPath(getRender().getIteration()));
	}


	private class BufferedImagePanel extends JPanel implements Printable
	{
		protected BufferedImage bi;

		public BufferedImagePanel(BufferedImage bi) { setImage(bi); }

		public BufferedImage getImage() { return(bi); }
		public void setImage(BufferedImage bi)
		{
			this.bi=bi;
			repaint();
			if(getParent()!=null) ((JComponent)getParent()).revalidate();
		}

		public void paint(Graphics g)
		{
			int x=(getSize().width-bi.getWidth())/2;
			int y=(getSize().height-bi.getHeight())/2;
			g.drawImage(bi,x,y,this);
		}

		public int print(Graphics g,PageFormat pf,int pi) throws PrinterException
		{
			if(pi>=1) return(Printable.NO_SUCH_PAGE);

			Graphics2D g2=(Graphics2D)g;
			g2.translate(pf.getImageableX(),pf.getImageableY());
			paint(g2);
			return(Printable.PAGE_EXISTS);
		}

		public Dimension getPreferredSize() { return(new Dimension(bi.getWidth(),bi.getHeight())); }
	}

	private void positionWindows()
	{
		parameters.setLocation(new Point(getLocation().x+getSize().width,getLocation().y));
		rules.setLocation(new Point(parameters.getLocation().x,parameters.getLocation().y+parameters.getSize().height));
		definitions.setLocation(new Point(rules.getLocation().x,rules.getLocation().y+rules.getSize().height));
	}

	public void setVisible(boolean visible)
	{
		super.setVisible(true);
		parameters.setVisible(true);
		rules.setVisible(true);
		definitions.setVisible(true);
	}

	public void show()
	{
		super.show();
		if(parameters.isVisible()) parameters.show();
		if(rules.isVisible()) rules.show();
		if(definitions.isVisible()) definitions.show();
	}

	void doNew()
	{
		if(!isSaved())
		{
			switch(JOptionPane.showConfirmDialog(this,"Save Preset before Closing?","Save Preset before Closing?",JOptionPane.YES_NO_CANCEL_OPTION))
			{
				case JOptionPane.YES_OPTION: doSave();
				case JOptionPane.NO_OPTION: setSaved(true); doNew();
			}
		}
		else
		{
			Preset p=new Preset();
			cf.setPreset(p);
			setRender(new Render(p,0,getRender().getWidth(),getRender().getHeight()));
			PathManager.clearPaths();
			setSavedLocation(null);
		}
	}

	void doOpen()
	{
		if(!isSaved())
		{
			switch(JOptionPane.showConfirmDialog(this,"Save Preset before Closing?","Save Preset before Closing?",JOptionPane.YES_NO_CANCEL_OPTION))
			{
				case JOptionPane.YES_OPTION: doSave();
				case JOptionPane.NO_OPTION: setSaved(true); doOpen();
			}
		}
		else
		{
			JFileChooser jfc=new JFileChooser(Preset.PRESETS);
			jfc.setFileFilter(new LSDFilter());
			if(jfc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)
			{
				try
				{
					File selectedFile=jfc.getSelectedFile();
					setSavedLocation(selectedFile);
					Preset p=new Preset(selectedFile);
					cf.setPreset(p);
					setRender(new Render(p,0,getRender().getWidth(),getRender().getHeight()));
					PathManager.clearPaths();
					PathManager.loadPaths(getPreset().getName());
				}
				catch(Exception e) { e.printStackTrace(); }
			}
		}
	}

	void doSave()
	{
		if(!isSaved())
		{
			if(getSavedLocation()==null) doSaveAs();
			else
			{
				try
				{
					getRender().getPreset().savePreset(getSavedLocation());
					PathManager.savePaths(getPreset().getName());
					setSaved(true);
				}
				catch(Exception e) { e.printStackTrace(); }
			}
		}
	}

	void doSaveAs()
	{
		File saveDir=((getSavedLocation()==null)?new File(Preset.PRESETS,getPreset().getName()+"_"+getRender().getIteration()+".gif"):getSavedLocation());
		JFileChooser jfc=new JFileChooser(saveDir);
		jfc.setFileFilter(new LSDFilter());
		if(jfc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION)
		{
			File selectedFile=jfc.getSelectedFile();
			String name=selectedFile.getName();
			if(name.endsWith(".lsd")) name=name.substring(0,name.indexOf(".lsd"));
			getPreset().setName(name);
			getParameterFrame().setName(name);
			setSavedLocation(selectedFile);
			doSave();
		}
	}

	void doRevert()
	{
		if(isSaved() || JOptionPane.showConfirmDialog(this,"Revert to Saved Preset?","Revert to Saved Preset?",JOptionPane.YES_NO_CANCEL_OPTION)==JOptionPane.YES_OPTION)
		{
			try
			{
				Preset p=new Preset(getSavedLocation());
				setRender(new Render(p,0,getRender().getWidth(),getRender().getHeight()));
				PathManager.clearPaths();
				PathManager.loadPaths(getPreset().getName());
			}
			catch(Exception e) { e.printStackTrace(); }
		}
	}

	void doSaveImageAs()
	{
		JFileChooser jfc=new JFileChooser(new File(Preset.IMAGES));
		if(jfc.showSaveDialog(this)==JFileChooser.APPROVE_OPTION)
			Factory.saveImage(getImagePanel().getImage(),jfc.getSelectedFile());
	}

	void doPrint()
	{
		//JOptionPane.showMessageDialog(this,"Printing support has not yet been added.");
		PrinterJob printJob=PrinterJob.getPrinterJob();
		printJob.setPrintable(getImagePanel());
		if(printJob.printDialog())
		{
			try { printJob.print(); }
			catch(Exception e) { e.printStackTrace(); }
		}
	}

	void doQuit()
	{
		if(!isSaved())
		{
			switch(JOptionPane.showConfirmDialog(this,"Save Preset before Quiting?","Save Preset before Quiting?",JOptionPane.YES_NO_CANCEL_OPTION))
			{
				case JOptionPane.YES_OPTION: doSave();
				case JOptionPane.NO_OPTION:	setSaved(true); doQuit();
			}
		}
		else
		{
			PathManager.clearPaths();
			System.exit(0);
		}
	}

	void doAbout() { new AboutBox(this); }

   private class NewAction extends AbstractAction
   {
      public NewAction() { super("New Preset"); }
	public void actionPerformed(ActionEvent ae) { doNew(); }
   }

   private class OpenAction extends AbstractAction
   {
      public OpenAction() { super("Open Preset..."); }
	  public void actionPerformed(ActionEvent ae) { doOpen(); }
   }

   private class SaveAction extends AbstractAction
   {
      public SaveAction() { super("Save Preset"); }
	  public void actionPerformed(ActionEvent ae) { doSave(); }
   }

   private class SaveAsAction extends AbstractAction
   {
      public SaveAsAction() { super("Save Preset As..."); }
	  public void actionPerformed(ActionEvent ae) { doSaveAs(); }
   }

	private class RevertAction extends AbstractAction
	{
		public RevertAction() { super("Revert"); }
		public void actionPerformed(ActionEvent ae) { doRevert(); }
	}

   private class SaveImageAsAction extends AbstractAction
   {
	   public SaveImageAsAction() { super("Save Image As..."); }
	   public void actionPerformed(ActionEvent ae) { doSaveImageAs(); }
   }

   private class PrintAction extends AbstractAction
   {
      public PrintAction() { super("Print Image..."); }
	  public void actionPerformed(ActionEvent ae) { doPrint(); }
   }

   private class QuitAction extends AbstractAction
   {
      public QuitAction() { super("Quit"); }
	  public void actionPerformed(ActionEvent ae) { doQuit(); }
   }

   private class AboutAction extends AbstractAction
   {
	   public AboutAction() { super("About LSystem"); }
	   public void actionPerformed(ActionEvent ae) { doAbout(); }
   }

   private class FrameToggler extends JCheckBoxMenuItem implements ActionListener
   {
      Frame frame;
      String name;

      public FrameToggler(Frame frame,String name)
      {
		 super("Show "+name);
         this.frame=frame;
		 this.name=name;
         addActionListener(this);
		 frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) { setSelected(false); }
			public void windowOpened(WindowEvent we) { setSelected(true); }
		});
	  }

      public void actionPerformed(ActionEvent ae) { frame.setVisible(!frame.isVisible()); }
   }

   private class LSDFilter extends FileFilter
   {
	   public boolean accept(File f) { return(f.isDirectory() || f.getName().endsWith(".lsd")); }
	   public String getDescription() { return("LSystem Preset Documents (*.lsd)"); }
   }
}

