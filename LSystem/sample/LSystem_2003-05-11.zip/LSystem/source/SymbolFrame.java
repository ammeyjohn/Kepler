import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

public class SymbolFrame extends JFrame
{
	protected ArrayList symbols,descriptions;
	
	public SymbolFrame()
	{
		super("List of Built-in LSystem Symbols");
		
		initTokens();
		
		JPanel contentPane=new JPanel(new BorderLayout());
		contentPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		contentPane.add("North",new JLabel("These are the built-in LSystem Instructions:",JLabel.CENTER));
		contentPane.add("West",createSymbolList());
		contentPane.add("Center",createDescriptionList());
		contentPane.add("South",new JLabel("Click anywhere in this frame to close it.",JLabel.CENTER));
		setContentPane(contentPane);
		pack();
		//setSize(new Dimension(getSize().width,2*getSize().height/3));
		setResizable(false);
		setLocation(1117,50);
		
		// hitting escape closes this window
		addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent ke) { if(ke.getKeyCode()==KeyEvent.VK_ESCAPE) setVisible(false); } });
		
		// clicking in the window closes it
		addMouseListener(new MouseAdapter() { public void mouseClicked(MouseEvent me) { setVisible(false); } });
	}
	
	protected void initTokens()
	{
		symbols=new ArrayList();
		descriptions=new ArrayList();
		
		addToken("F","Move forward drawing line");
		addToken("f","Move forward without drawing line");
		addToken("+","Turn left");
		addToken("-","Turn right");
		addToken("[","Save state and branch new turtle");
		addToken("]","End turtle and return to saved state");
		addToken("(","Decrement turning angle");
		addToken(")","Increment turning angle");
		addToken("\\","Decrement line width");
		addToken("/","Increment line width");
		addToken("<","Divide line length by scale factor");
		addToken(">","Multiply line length by scale factor");
		addToken("{","Open a polygon");
		addToken("}","Close a polygon and fill it");
		addToken("|","Reverse direction");
		addToken("&","Swap meaning of + and -");
		addToken("^","Divide angle by angle scale");
		addToken("_","Divide angle by angle scale");
		addToken("w","Divide width by width scale");
		addToken("W","Divide width by width scale");
		addToken("!","Decrement length by length increment");
		addToken("@","Increment length by length increment");
	}
	
	protected void addToken(String symbol,String description)
	{
		symbols.add(symbol);
		descriptions.add(description);
	}
	
	private JPanel createSymbolList()
	{
		JPanel symbolList=new JPanel(new GridLayout(0,1));
		symbolList.setBorder(BorderFactory.createEmptyBorder(10,0,10,10));
		for(int i=0;i<symbols.size();i++)
			symbolList.add(new JLabel((String)symbols.get(i)));
		return(symbolList);
	}
	
	private JPanel createDescriptionList()
	{
		JPanel descriptionList=new JPanel(new GridLayout(0,1));
		descriptionList.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
		for(int i=0;i<descriptions.size();i++)
			descriptionList.add(new JLabel((String)descriptions.get(i)));
		return(descriptionList);
	}
}
