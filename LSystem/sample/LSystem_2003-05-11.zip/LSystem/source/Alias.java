/*
	Class to parse and store name/value text pairs.
	Steven N. Severinghaus (sns@sigmadd.com)
*/

public class Alias implements Cloneable
{
	public static final int RULE=0;
	public static final int DEFINITION=1;
	public static final String[] typeNames=new String[]{"Rule","Definition"};
	
	char name;        // Name assigned to value
	String value;     // Value assigned to name
	int type;         // Type of alias

/*
	Constructs a new alias given the name, value, and type.
*/
	public Alias(char name,String value,int type)
	{
		this.name=name;
		this.value=value;
		this.type=type;
	}

/*
	Basically for searching purposes. (see equals())
*/
	Alias(char c) { name=c; }
	Alias() { }

/*
	Parse a string to find name and value.
	This needs to get smarter.
*/
	public static Alias parseAlias(String alias)
	{
		char c=alias.charAt(0);
		String s=alias.substring(5,alias.length());
		return(new Alias(c,s,0));
	}

/*
	Accessors.
*/
	public char getName() { return(name); }
	public String getValue() { return(value); }
	public int getType() { return(type); }
	public String getTypeName() { return(getTypeName(getType())); }
	
	public void setName(char name) { this.name=name; }
	public void setValue(String value) { this.value=value; }
	public void setType(int type)
	{
		if(type==RULE || type==DEFINITION) this.type=type;
		else throw(new IllegalTypeException());
	}
	
	public static String getTypeName(int type) { return(typeNames[type]); }

/*
	Equality is most useful if considered just as the
	names being equal.
*/
	public boolean equals(char c) { return(equals(new Alias(c))); }

	public boolean equals(Object o)
	{
		if(!(o instanceof Alias)) return(false);
		else return(equals((Alias)o));
	}

	public boolean equals(Alias a)
	{
		if(a.getName()==name) return(true);
		else return(false);
	}

/*
	Make a completely new copy of this alias.
*/
	public Object clone() { return(new Alias(name,value,type)); }

/*
	Make a string representation.
*/
	public String toString() { return(""+name+" -> "+value); }
}

