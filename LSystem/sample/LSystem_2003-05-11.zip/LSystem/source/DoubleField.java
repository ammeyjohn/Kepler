/*
	Text field for bounded integers (restrictions on min and max) and increment/decrement buttons.
	Ensures valid entries and exposes getValue() and setValue(int).
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class DoubleField extends JPanel
{
	protected final SmartTextField tf;
	protected final JScrollBar sb;
	
	protected double value;
	protected double minimum;
	protected double maximum;
	protected double increment;
	protected int columns;
	
	protected final double defaultValue;
	
	public DoubleField(double value,double minimum,double maximum,double increment,int columns)
	{
		this.value=value;
		this.minimum=minimum;
		this.maximum=maximum;
		this.increment=increment;
		this.columns=columns;
		defaultValue=value;
		setLayout(new BorderLayout());
		
		tf=new SmartTextField(Double.toString(getValue()),getColumns());
		tf.addChangeListener(new ChangeListener() { public void stateChanged(ChangeEvent ce) { validateText(); } });
		add("Center",tf);
		
		sb=new JScrollBar(JScrollBar.VERTICAL,getScaledMaximum()-getScaledValue(),0,getScaledMinimum(),getScaledMaximum());
		sb.setBlockIncrement(getScaledIncrement());
		sb.setUnitIncrement(getScaledIncrement());
		sb.setPreferredSize(new Dimension(sb.getPreferredSize().width,tf.getPreferredSize().height));
		sb.addAdjustmentListener(new AdjustmentListener() { 
			public void adjustmentValueChanged(AdjustmentEvent e) { setValue(getNormalizedValue(sb.getMaximum()-e.getValue())); } 
		});
		add("East",sb);
		
	}

	public DoubleField(double value,double minimum,double maximum,double increment) { this(value,minimum,maximum,increment,10); }
	public DoubleField(double value,double minimum,double maximum) { this(value,minimum,maximum,1,10); }
	public DoubleField(double value) { this(value,0,100,1,10); }
	
	protected void validateText()
	{	
		String text=tf.getText();
		if(text.equals("")) text=Double.toString(defaultValue);
		
		try 
		{ 
			double value=Double.parseDouble(text); 
			if(value<getMinimum()) value=getMinimum();
			if(value>getMaximum()) value=getMaximum();
			setValue(value);
		}
		catch(NumberFormatException e) 
		{
			displayError("You must enter a valid double in this text field");
		}
	}
	

	public double getValue() { return(value); }
	public double getMinimum() { return(minimum); }
	public double getMaximum() { return(maximum); }
	public double getIncrement() { return(increment); }
	public int getColumns() { return(columns); }
	
	public void setValue(double value) 
	{ 
		if(value!=this.value)
		{
			this.value=value; 
			sb.setValue(getScaledMaximum()-getScaledValue()); 
			tf.setText(Double.toString(value)); 
			fireChangeEvent(); 
		}
	}
	public void setMinimum(double minimum) { this.minimum=minimum; sb.setMinimum(getScaledMinimum()); }
	public void setMaximum(double maximum) { this.maximum=maximum; sb.setMaximum(getScaledMaximum()); }
	public void setIncrement(double increment) { this.increment=increment; sb.setUnitIncrement(getScaledIncrement()); sb.setBlockIncrement(getScaledIncrement()); }
	public void setColumns(int columns) { this.columns=columns; tf.setColumns(columns); }
	
	private int getScaledValue() { return((int)Math.floor((getValue()-getMinimum())/getIncrement())); }
	private int getScaledMinimum() { return(0); }
	private int getScaledMaximum() { return((int)Math.ceil((getMaximum()-getMinimum())/getIncrement())); }
	private int getScaledIncrement() { return(1); }
	
	private double getNormalizedValue(int value) { return(Math.min(getMinimum()+value*getIncrement(),getMaximum())); }

/*
	Passes the error message along to the SmartTextField inside this IntegerField.
*/
	public void displayError(String error) { tf.displayError(error); }
	
/*
	Standard code to make this class a source of ChangeEvents.
*/
	protected EventListenerList listenerList=new EventListenerList();
	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	protected void fireChangeEvent()
	{
		ChangeEvent ce=new ChangeEvent(this);
		Object[] listeners=listenerList.getListenerList();
		for(int i=listeners.length-2;i>=0;i-=2) 
			if(listeners[i]==ChangeListener.class) 
				((ChangeListener)listeners[i+1]).stateChanged(ce);
	}
}
