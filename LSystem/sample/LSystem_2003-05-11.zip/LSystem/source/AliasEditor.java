/*
	Edits a rule or definition with validation.
	NOTE: make it so that escape is like hitting cancel (how do you do that in Swing?)
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.Keymap;

public class AliasEditor extends JDialog
{
	protected Preset preset;
	protected int type;
	protected Alias alias;
	protected final JTextField name,value;
	protected boolean oldAlias;
	
	public AliasEditor(Frame parent,Preset preset,int type)
	{
		super(parent,"Add "+Alias.getTypeName(type),true);
		this.preset=preset;
		this.type=type;
		
		JPanel cp=new JPanel(); // content pane
		cp.setLayout(new BorderLayout());
		cp.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		name=new JTextField(2);
		value=new JTextField(20);
		
		cp.add("North",createEditorPanel());
		cp.add("South",createButtonPanel());
		setContentPane(cp);
		pack();
		
		// hitting escape closes this window
		addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent ke) { if(ke.getKeyCode()==KeyEvent.VK_ESCAPE) setVisible(false); } });
		
		int mx=parent.getLocation().x+parent.getSize().width/2-getSize().width/2;
		int my=parent.getLocation().y+parent.getSize().height/2-getSize().height/2;
		setLocation(new Point(mx,my));
	}
	
	public AliasEditor(Frame parent,Preset preset,Alias alias)
	{
		this(parent,preset,alias.getType());
		setTitle("Edit "+Alias.getTypeName(alias.getType()));
		oldAlias=true;
		name.setText(""+alias.getName());
		value.setText(alias.getValue());
	}
	
	private JPanel createEditorPanel()
	{
		JPanel ep=new JPanel(); // editor panel
		ep.setLayout(new BorderLayout());
		
		JPanel np=new JPanel(); // name panel (name + "->")
		np.setLayout(new BoxLayout(np,BoxLayout.X_AXIS));
		np.add(name);
		np.add(Box.createHorizontalStrut(10));
		JLabel arrow=new JLabel("->");
		arrow.setFont(new Font("Monospaced",Font.BOLD,14));
		np.add(arrow);
		np.add(Box.createHorizontalStrut(10));
		ep.add("West",np);
		
		ep.add("Center",value);
		
		return(ep);
	}
	
	private JPanel createButtonPanel()
	{
		JPanel bp=new JPanel();
		bp.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		JButton cancel=new JButton("Cancel");
		cancel.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { setVisible(false); } });
		bp.add(cancel);
		
		JButton ok=new JButton("OK");
		ok.setPreferredSize(cancel.getPreferredSize());
		ok.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { closeRequested(); } });
		getRootPane().setDefaultButton(ok);
		bp.add(ok);
		
		return(bp);
	}
	
	private void closeRequested()
	{
		boolean valid=(name.getText().length()==1 && checkName() && checkValue());
		if(valid)
		{
			alias=new Alias(name.getText().charAt(0),value.getText(),type);
			setVisible(false);
		}
		else JOptionPane.showMessageDialog(this,"You have entered an invalid "+Alias.getTypeName(type),"Invalid "+Alias.getTypeName(type),JOptionPane.ERROR_MESSAGE);
	}
	
	private boolean checkName() 
	{
		boolean valid;
		char n=name.getText().charAt(0);
		
		if(type==Alias.RULE) valid=checkRuleName(n);
		else valid=checkDefinitionName(n);
		
		return(valid);
	}
	private boolean checkValue() 
	{ 
		boolean valid;
		String v=value.getText();
		
		if(type==Alias.RULE) valid=checkRuleValue(v);
		else valid=checkDefinitionValue(v);
		
		return(valid);
	}
	
	protected boolean checkRuleName(char name) 
	{ 
		return(preset.isDefined(name) && (oldAlias || !preset.isRule(name))); 
	}
	
	protected boolean checkRuleValue(String value)
	{
		return(preset.allDefined(value));
	}
	
	protected boolean checkDefinitionName(char name)
	{
		return(!preset.isBuiltin(name) && (oldAlias || !preset.isDefinition(name)));
	}
	
	protected boolean checkDefinitionValue(String value)
	{
		return(preset.allDefined(value));
	}
	
	public Alias getAlias() { return(alias); }

/*
	Removes the "enter" keymap from textfields so they go to the OK button.
*/
	static
	{
		JTextField f = new JTextField();
		KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		Keymap map = f.getKeymap();
		map.removeKeyStrokeBinding(enter);
	}
}
