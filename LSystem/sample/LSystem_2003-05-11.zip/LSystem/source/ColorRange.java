/*
	Class for holding a color range.
*/

import java.awt.Color;

public class ColorRange
{
	Color color;    // Color for this range
	double range;   // Value of range

/*
	Constructs a new color range.
*/
	ColorRange(Color color,double range)
	{
		setColor(color);
		setRange(range);
	}

	ColorRange() { this(Color.white,0); }

	public String toString()
	{
		String s=""+range+" RGB ";
		s+=color.getRed()+" "+color.getGreen()+" "+color.getBlue();
		return(s);
	}

/*
	Accessor methods.
*/
	public Color getColor() { return(color); }
	public double getRange() { return(range); }

	public void setColor(Color color) { this.color=color; }
	public void setRange(double range) { this.range=range; }
}

