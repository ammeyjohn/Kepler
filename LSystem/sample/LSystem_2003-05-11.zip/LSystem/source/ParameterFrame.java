/*
	Displays the editable state information for a Preset (less its rules and definitions).
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class ParameterFrame extends JFrame
{
	protected Preset preset;
	protected final JTextField nameField;
	public static final String TITLE="Parameters";
	
	public ParameterFrame(Preset preset)
	{
		super(TITLE);
		
		nameField=new JTextField();
		nameField.setEditable(false);
		JPanel contentPane=new JPanel();
		contentPane.setLayout(new BorderLayout());
		contentPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		contentPane.add("West",createLabelPanel());
		setContentPane(contentPane);
		//fieldPanel added by setPreset()
		setPreset(preset);
		pack();
		setResizable(false);
        setLocation(830,50);
	}

	private JPanel createLabelPanel()
	{
		JPanel labelPanel=new JPanel();
		labelPanel.setLayout(new GridLayout(0,1));
		labelPanel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
		String[] labels=new String[] { "Name","Description","Axiom","Angle","Angle Increment","Angle Scale","Width","Width Increment","Width Scale","Length","Length Increment","Length Scale" };
		for(int i=0;i<labels.length;i++)
			labelPanel.add(new JLabel(labels[i]+":"));
		
		return(labelPanel);
	}

	private JPanel createFieldPanel()
	{
		JPanel fieldPanel=new JPanel();
		fieldPanel.setLayout(new GridLayout(0,1));
		
		// Name
		nameField.setText(getPreset().getName());
		fieldPanel.add(nameField);
		
		// Description
		SmartTextField description=new SmartTextField(getPreset().getDescription());
		description.setZeroLengthValid(false);
		description.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				SmartTextField src=(SmartTextField)ce.getSource();
				getPreset().setDescription(src.getText()); 
			}
		});
		fieldPanel.add(description);
		
		// Axiom
		SmartTextField axiom=new SmartTextField(getPreset().getAxiom());
		axiom.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				SmartTextField src=(SmartTextField)ce.getSource();
				try { getPreset().setAxiom(src.getText()); }
				catch(InvalidAxiomException e) { src.displayError("You must enter a valid axiom for this preset."); }
			}
		});
		fieldPanel.add(axiom);
		
		DoubleField df; // used for remaining fields
		
		// Angle
		df=new DoubleField(getPreset().getAngle(),Preset.ANGLE_MIN,Preset.ANGLE_MAX,1);
		df.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent ce)
			{
				DoubleField src=(DoubleField)ce.getSource();
				try { getPreset().setAngle(src.getValue()); }
				catch(InvalidAngleException e) { src.displayError("You must enter a valid axiom for this preset."); }
			}
		});
		fieldPanel.add(df);
				
		// Angle Increment
		df=new DoubleField(getPreset().getAngleIncrement(),Preset.ANGLE_INCREMENT_MIN,Preset.ANGLE_INCREMENT_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setAngleIncrement(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Angle Scale
		df=new DoubleField(getPreset().getAngleScale(),Preset.ANGLE_SCALE_MIN,Preset.ANGLE_SCALE_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setAngleScale(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Width
		df=new DoubleField(getPreset().getWidth(),Preset.WIDTH_MIN,Preset.WIDTH_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setWidth(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Width Increment
		df=new DoubleField(getPreset().getWidthIncrement(),Preset.WIDTH_INCREMENT_MIN,Preset.WIDTH_INCREMENT_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setWidthIncrement(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Width Scale
		df=new DoubleField(getPreset().getWidthScale(),Preset.WIDTH_SCALE_MIN,Preset.WIDTH_SCALE_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setWidthScale(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Length
		df=new DoubleField(getPreset().getLength(),Preset.LENGTH_MIN,Preset.LENGTH_MAX,1);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setLength(src.getValue());
			}
		});
		fieldPanel.add(df);
		
		// Length Increment
		df=new DoubleField(getPreset().getLengthIncrement(),Preset.LENGTH_INCREMENT_MIN,Preset.LENGTH_INCREMENT_MAX,0.05);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setLengthIncrement(src.getValue());
			}
		});
		fieldPanel.add(df);

		// Length Scale
		df=new DoubleField(getPreset().getLengthScale(),Preset.LENGTH_SCALE_MIN,Preset.LENGTH_SCALE_MAX,0.05);
		df.addChangeListener(new ChangeListener() { 
			public void stateChanged(ChangeEvent ce) 
			{ 
				DoubleField src=(DoubleField)ce.getSource();
				getPreset().setLengthScale(src.getValue());
			}
		});
		fieldPanel.add(df);

		return(fieldPanel);
	}
	
	public Preset getPreset() { return(preset); }
	public void setPreset(Preset preset) 
	{ 
		this.preset=preset; 
		if(getContentPane().getComponentCount()>1)
			getContentPane().remove(1);
		getContentPane().add("Center",createFieldPanel()); 
		updateTitle();
		pack();
	}
	
	public void updateTitle() { setTitle(TITLE+": "+preset.getDescription()); }
	
	public void setName(String name) { nameField.setText(name); }
}
