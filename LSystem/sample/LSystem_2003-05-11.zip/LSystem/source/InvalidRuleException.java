public class InvalidRuleException extends Exception { }
