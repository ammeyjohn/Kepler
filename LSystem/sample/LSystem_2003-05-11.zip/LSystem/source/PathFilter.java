/*
	Filters path files with the given name.
*/

import java.io.File;
import java.io.FileFilter;

public class PathFilter implements FileFilter
{
	protected String name;

	public PathFilter(String name) { this.name=name; }

	public boolean accept(File pathname)
	{
		return(pathname.getName().startsWith(name) && pathname.getName().endsWith(PathManager.PATH_SUFFIX));
	}
}

