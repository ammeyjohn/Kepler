/*
	Specific ChangeEvent which details what preset info has changed.
*/

import javax.swing.event.ChangeEvent;

public class PresetChangeEvent extends ChangeEvent
{
	public static final int NAME=0;
	public static final int DESCRIPTION=1;
	public static final int RULES=2;
	public static final int DEFINITIONS=3;
	public static final int AXIOM=4;
	public static final int ANGLE=5;
	public static final int ANGLE_INCREMENT=6;
	public static final int ANGLE_SCALE=12;
	public static final int WIDTH=7;
	public static final int WIDTH_INCREMENT=8;
	public static final int WIDTH_SCALE=13;
	public static final int LENGTH=9;
	public static final int LENGTH_INCREMENT=14;
	public static final int LENGTH_SCALE=10;
	public static final int COLOR=11;

	protected int type;

	public PresetChangeEvent(Object source,int type)
	{
		super(source);
		this.type=type;
	}

	public int getType() { return(type); }
}
