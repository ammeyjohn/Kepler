import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class AboutBox extends JDialog
{
	public AboutBox(Frame parent)
	{
		super(parent,"About LSystem",true);
		
		JPanel contentPane=new JPanel(new BorderLayout());
		contentPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		JTextArea text=new JTextArea(readAboutText());
		text.setEditable(false);
		text.setMargin(new Insets(10,10,10,10));
		JScrollPane jsp=new JScrollPane(text);
		jsp.setPreferredSize(new Dimension(Math.min(400,jsp.getPreferredSize().width),Math.min(400,jsp.getPreferredSize().height)));
		
		contentPane.add("Center",jsp);
		setContentPane(contentPane);
		pack();
		setResizable(false);
		
		int mx=parent.getLocation().x+parent.getSize().width/2-getSize().width/2;
		int my=parent.getLocation().y+parent.getSize().height/2-getSize().height/2;
		setLocation(new Point(mx,my));
		
		// hitting escape closes this window
		addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent ke) { if(ke.getKeyCode()==KeyEvent.VK_ESCAPE) setVisible(false); } });
		
		addMouseListener(new MouseAdapter() { public void mouseClicked(MouseEvent me) { setVisible(false); } });
		
		setVisible(true);
	}
	
	public String readAboutText()
	{
		String aboutText="";
		String cur;
		
		try
		{
			BufferedReader br=new BufferedReader(new FileReader("README.txt"));
			while((cur=br.readLine())!=null)
				aboutText+=cur+"\n";
		}
		catch(Exception e) { aboutText=e.toString(); }
		
		return(aboutText);
	}
}
