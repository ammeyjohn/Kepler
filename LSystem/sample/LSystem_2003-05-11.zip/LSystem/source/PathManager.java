/*
	Manages the intricacies of path caching.
*/

import java.io.*;

public class PathManager
{
	public static final String PATH_SUFFIX=".oos";

/*
	Clears out the "current" paths.
*/
	public static void clearPaths()
	{
		File[] paths=new File(Preset.PATHS).listFiles(new PathFilter("current"));
		for(int j=0;j<paths.length;j++)
			paths[j].delete();
	}

/*
	Makes a copy of all paths from the given name to the given name (e.g. "current"->"some_preset").
*/
	public static void copyPaths(String fromName,String toName)
	{
		File[] paths=new File(Preset.PATHS).listFiles(new PathFilter(fromName));
		for(int j=0;j<paths.length;j++)
		{
			String pathName=paths[j].getName();
			int iteration=Integer.parseInt(pathName.substring(pathName.indexOf("_")+1,pathName.indexOf(PATH_SUFFIX)));
			copyFile(paths[j],new File(Preset.PATHS,toName+"_"+iteration+PATH_SUFFIX));
		}
	}

/*
	Makes a copy of src and writes it out to dest (like "cp src dest" in Unix).
*/
	public static void copyFile(File src,File dest)
	{
		try
		{
			BufferedInputStream in=new BufferedInputStream(new DataInputStream(new FileInputStream(src)));
			BufferedOutputStream out=new BufferedOutputStream(new DataOutputStream(new FileOutputStream(dest)));

			int cur;
			while((cur=in.read())!=-1) out.write(cur);
			out.flush();
			out.close();
		}
		catch(Exception e) { e.printStackTrace(); }
	}

	public static void savePaths(String name) { copyPaths("current",name); }
	public static void loadPaths(String name) { copyPaths(name,"current"); }

/*
	Saves out a path.
*/
	public static void savePath(char[] p,File f)
	{
		try { new ObjectOutputStream(new FileOutputStream(f)).writeObject(p); }
		catch(Exception e) { e.printStackTrace(); }
	}

	public static void savePath(char[] path,Preset preset,int iter)
	{
		File f=new File(Preset.PATHS+preset.getName()+"_"+iter+PATH_SUFFIX);
		savePath(path,f);
	}

	public static void savePath(char[] path,int iter)
	{
		File f=new File(Preset.PATHS+"current_"+iter+PATH_SUFFIX);
		savePath(path,f);
	}

/*
	Loads a stored path from a file.
*/
	public static char[] loadPath(String name,int iter)
	{
		char[] path=null;

		try
		{
			File f=new File(Preset.PATHS+name+"_"+iter+PATH_SUFFIX);
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
			path=(char[])ois.readObject();
		}
		catch(Exception e) { e.printStackTrace(); }

		return(path);
	}

	public static char[] loadPath(Preset p,int iter) { return(loadPath(p.getName(),iter)); }
	public static char[] loadPath(int iter) { return(loadPath("current",iter)); }
	public static char[] loadPath(Render r) { return(loadPath(r.getPreset(),r.getIteration())); }

/*
	Finds the highest iteration done <= iteration.
*/
	public static int findPath(String name,int iteration)
	{
		int highIter=-1;

		int iter;
		for(iter=iteration;iter>=0;iter--)
		{
			File f=new File(Preset.PATHS+name+"_"+iter+PATH_SUFFIX);
			if(f.canRead())
			{
				highIter=iter;
				break;
			}
		}

		return(highIter);
	}

	public static int findPath(int iter) { return(findPath("current",iter)); }

}

