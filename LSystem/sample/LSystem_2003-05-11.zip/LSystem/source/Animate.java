import java.io.*;
public class Animate
{
	public static void main(String[] args)
	{
		Preset p=null;
		try { p=new Preset(new File(Preset.PRESETS+"colon.lsd")); }
		catch(Exception e) { e.printStackTrace(); }

		int iter=7;
		int width=200;
		int height=200;
		
		double start=15.675;
		double end=30;
		double step=.05;

		for(double angle=start;angle<=end;angle+=step)
		{
			System.out.println("Angle: "+(float)angle);
			try { p.setAngle(angle); }
			catch(Exception e) { e.printStackTrace(); }
			Render r=new Render(p,iter,width,height);
			Factory f=new Factory(r);
			f.run();
			String nom;
			if(angle<10.0) nom="anims/colon/colon_0"+(float)angle+".gif";
			else nom="anims/colon/colon_"+(float)angle+".gif";
			System.out.println(nom);
			Factory.saveImage(f.getImage(),new File(nom));
		}
	}
}

