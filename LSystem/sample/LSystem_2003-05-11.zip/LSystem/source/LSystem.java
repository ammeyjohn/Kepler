/*
	Main class for LSystem. Can drive a GUI or command-line interface.
*/

public class LSystem
{
	public static void main(String[] args)
	{
		if(args.length==0) new Presenter(new Render()).setVisible(true);
		else CommandLine.processJob(args);
	}
}

