/*
	Specific ChangeEvent which details what Render info has changed.
*/

import javax.swing.event.ChangeEvent;

public class RenderChangeEvent extends ChangeEvent
{
	public static final int PRESET=0;
	public static final int ITERATION=1;
	public static final int SIZE=2;

	protected int type;

	public RenderChangeEvent(Object source,int type)
	{
		super(source);
		this.type=type;
	}

	public int getType() { return(type); }
}
