/*
	Turtle to keep track of cursor position and info.
	Understands directives: F,f,+,-,<,>,(,),/,\,|,&
*/

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Line2D;

public class Turtle
{
	// Turtle execution modes
	public static final int TEST=0;
	public static final int DRAW=1;
	public static final int POLY=2;

	// Properties that are inherited and shared
	Preset preset;      // Preset information
	Graphics2D g;       // Graphics for drawing path
	int width;          // Rendering width
	int height;         // Rendering height
	double top,bottom;  // Bounding top and bottom
	double left,right;  // Bounding left and right
	Factory factory;

	// Properties that are unique to this turtle
	double x,y,dir;              // Position and direction
	double angle,length,lwidth;  // Current values
	int cIndex;
	Paint paint;

	Point2D scale;  // Pixels per turtle unit

/*
	Constructs a shiny, new turtle for anyone who brings me
	the head of Colonel Montoya.
*/
	Turtle(Preset preset,Graphics2D g,int width,int height,Factory factory)
	{
		setFactory(factory);
		setPreset(preset);
		setGraphics(g);
		setWidth(width);
		setHeight(height);
		setX(0.0);
		setY(0.0);
		setDirection(0.0);
		setAngle(preset.getAngle()*Math.PI/180);
		setLength(preset.getLength());
		setLineWidth(preset.getWidth());
	}

/*
	Change the cursor angle or position, figure out bounds.
*/
	public void execute(char c,int mode)
	{
		switch(c)
		{
			case 'F':
				if(mode==DRAW)
				{
					double ox=x;
					double oy=y;
					forward();
					int x1=(int)((ox-left)/scale.getX());
					int y1=(int)((oy-bottom)/scale.getY());
					int x2=(int)((x-left)/scale.getX());
					int y2=(int)((y-bottom)/scale.getY());

					ColorScheme cs=factory.getPreset().getColorScheme();
					if(cs.getType()==ColorScheme.TYPE_INDEXED)
						setPaint(cs.getIndexedColor(cIndex));
					else if(cs.getType()==ColorScheme.TYPE_DISCRETE)
						setPaint(cs.getDiscreteColor(factory.getFCount()));
					else if(cs.getType()==ColorScheme.TYPE_CONTINUOUS)
						setPaint(cs.getContinuousColor(factory.getFCount(),factory.getFTotal()));

					g.setStroke(new BasicStroke((float)lwidth));
					g.draw(new Line2D.Double(x1,y1,x2,y2));
				}
				else forward();
				break;
			case 'f': forward(); break;
			case '+': dir+=angle; break;
			case '-': dir-=angle; break;
			case '@': length+=preset.getLengthIncrement(); break;
			case '!': length-=preset.getLengthIncrement(); break;
			case '>': length*=preset.getLengthScale(); break;
			case '<': length/=preset.getLengthScale(); break;
			case '(': angle-=preset.getAngleIncrement()*Math.PI/180d; break;
			case ')': angle+=preset.getAngleIncrement()*Math.PI/180d; break;
			case '^': angle*=preset.getAngleScale(); break;
			case '_': angle/=preset.getAngleScale(); break;
			case '/': lwidth+=preset.getWidthIncrement(); break;
			case '\\': lwidth-=preset.getWidthIncrement(); break;
			case 'W': lwidth*=preset.getWidthScale(); break;
			case 'w': lwidth/=preset.getWidthScale(); break;
			case '|': dir=Math.PI+dir; break;
			case '&': angle=-angle; break;
			case '`': cIndex--; break;
			case '\'': cIndex++; break;
		}

		if(mode==TEST)
		{
			if(x>right) right=x;
			if(x<left) left=x;
			if(y>bottom) bottom=y;
			if(y<top) top=y;
		}
	}

/*
	Make the bounds square again.
*/
	public void fixRatio()
	{
		double ar=(double)width/(double)height;
		double dx=right-left;
		double dy=bottom-top;
		if((dx/dy)<ar) // i.e. dx is too small
		{
			double d=(dy*ar-dx)/2;
			left-=d;
			right+=d;
		}
		else if((dx/dy)>ar) // i.e. dy is too small
		{
			double d=(dx/ar-dy)/2;
			top-=d;
			bottom+=d;
		}
	}

/*
	Move the cursor forward one step.
*/
	void forward()
	{
        /*
		x+=(Math.random()+.5)*length*Math.cos(dir);
		y+=(Math.random()+.5)*length*Math.sin(dir);
        */
		x+=length*Math.cos(dir);
		y+=length*Math.sin(dir);
	}

/*
	Create a new turtle in a new environment.
*/
	public Turtle fork()
	{
		Turtle t=new Turtle(preset,g,width,height,factory);

		t.setTop(top);
		t.setBottom(bottom);
		t.setLeft(left);
		t.setRight(right);
		t.setScale(scale);
		t.setX(x);
		t.setY(y);
		t.setDirection(dir);
		t.setAngle(angle);
		t.setLength(length);
		t.setLineWidth(lwidth);
		t.setCIndex(cIndex);
		t.setPaint(paint);

		return(t);
	}

	public Preset getPreset() { return(preset); }
	public Graphics2D getGraphics() { return(g); }
	public int getWidth() { return(width); }
	public int getHeight() { return(height); }
	public double getTop() { return(top); }
	public double getBottom() { return(bottom); }
	public double getLeft() { return(left); }
	public double getRight() { return(right); }
	public double getX() { return(x); }
	public double getY() { return(y); }
	public double getDirection() { return(dir); }
	public double getAngle() { return(angle); }
	public double getLength() { return(length); }
	public double getLineWidth() { return(lwidth); }
	public Point2D getScale() { return(scale); }
	public Factory getFactory() { return(factory); }
	public int getCIndex() { return(cIndex); }
	public Paint getPaint() { return(paint); }

	public void setFactory(Factory factory) { this.factory=factory; }
	public void setPreset(Preset preset) { this.preset=preset; }
	public void setGraphics(Graphics2D g) { this.g=g; }
	public void setWidth(int width) { this.width=width; }
	public void setHeight(int height) { this.height=height; }
	public void setTop(double top) { this.top=top; }
	public void setBottom(double bottom) { this.bottom=bottom; }
	public void setLeft(double left) { this.left=left; }
	public void setRight(double right) { this.right=right; }
	public void setX(double x) { this.x=x; }
	public void setY(double y) { this.y=y; }
	public void setDirection(double dir) { this.dir=dir; }
	public void setAngle(double angle) { this.angle=angle; }
	public void setLength(double length) { this.length=length; }
	public void setLineWidth(double lwidth) { this.lwidth=lwidth; }
	public void setScale(double ppux,double ppuy) { scale=new Point2D.Double(ppux,ppuy); }
	public void setScale(Point2D scale) { this.scale=scale; }
	public void setCIndex(int cIndex) { this.cIndex=cIndex; }
	public void setPaint(Paint paint) { this.paint=paint; g.setPaint(paint); }
}

