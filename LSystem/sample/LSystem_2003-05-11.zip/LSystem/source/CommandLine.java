/*
	Handle command line arguments 'n stuff.

    java LSystem presets/colon.lsd iter width height
*/

import java.lang.reflect.*;
import java.io.File;
import java.util.HashMap;

public abstract class CommandLine
{
	public static void processJob(String[] args)
	{
		Preset p=null;
		try { p=new Preset(new File(args[0])); }
		catch(Exception e) { e.printStackTrace(); }
		
		String[] ss=new String[args.length-4];
		for(int j=0;j<ss.length;j++) ss[j]=args[j+4];

		setupOptions(p,ss);

		int iter=new Integer(args[1]).intValue();
		int width=new Integer(args[2]).intValue();
		int height=new Integer(args[3]).intValue();
		System.out.println("Initializing...");
		Render r=new Render(p,iter,width,height);
		Factory f=new Factory(r);
		System.out.println("Running...");
		f.run();
		System.out.println("Saving...");
		Factory.saveImage(f.getImage(),p,iter);
		System.out.println("Done.");
	}

	public static void setupOptions(Preset p,String[] args)
	{
		OptionMap om=new OptionMap();
		for(int j=0;j<args.length;j++)
		{
			int argc=om.getArgc(args[j]);
			String[] arg=new String[argc];
			for(int k=0;k<argc;k++) arg[k]=args[j+k+1];
			om.setOption(p,args[j],arg);
			j+=argc;
		}
	}

	private static class OptionMap
	{
		HashMap ham;

		OptionMap()
		{
			ham=new HashMap(2);
			Class[] tum1=new Class[]{Double.class};
			ham.put("a",new Option("a","setAngle",1,tum1));
			ham.put("ai",new Option("ai","setAngleIncrement",1,tum1));
		}

	/*
		Set the aliased option of the object to the arguments given.
	*/
		public void setOption(Object obj,String alias,String[] args)
		{
			try
			{
				Option o=(Option)ham.get(alias);
				Class c=obj.getClass();
				Method[] ms=c.getMethods();
				Method m=null;
				for(int j=0;j<ms.length;j++)
					if(ms[j].getName().equals(o.getMethod())) { m=ms[j]; break; }

				//jAvA $uX
				//Method m=c.getMethod(o.getMethod(),o.getClasses());

				Object[] argo=new Object[args.length];
				for(int j=0;j<argo.length;j++)
				{
					Constructor con=o.getClasses()[j].getConstructor(new Class[]{String.class});
					argo[j]=con.newInstance(new Object[]{args[j]});
				}

				m.invoke(obj,argo);
			}
			catch(Exception e) { e.printStackTrace(); }
		}

		public int getArgc(String alias) { return(((Option)ham.get(alias)).getArgc()); }

		private class Option
		{
			String alias;
			String method;
			int argc;
			Class[] classes;

			Option(String alias,String method,int argc,Class[] classes)
			{
				this.alias=alias;
				this.method=method;
				this.argc=argc;
				this.classes=classes;
			}

			public String getAlias() { return(alias); }
			public String getMethod() { return(method); }
			public int getArgc() { return(argc); }
			public Class[] getClasses() { return(classes); }
		}
	}
}

