/*	
	A JTextField that fires ChangeEvents when it loses focus or the user hits return 
	and the value has changed since the last ChangeEvent was fired.
	Also supports the display of an error message if the entered text is in some way invalid.
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class SmartTextField extends JTextField
{
	protected String oldText;          // value of getText() last time a ChangeEvent was fired
	protected boolean zeroLengthValid; // is a blank value (getText().equals("")) acceptable
	
	public SmartTextField(String text,int columns)
	{
		super(text,columns);
		oldText=text; // nothing is fired when this class is constructed
		zeroLengthValid=true;
		
		// the value of the text is checked when the user hits return or this component loses focus
		addActionListener(new ActionListener() { public void actionPerformed(ActionEvent ae) { checkText(); } });
		addFocusListener(new FocusAdapter() { public void focusLost(FocusEvent fe) { checkText(); } });
	}
	
	public SmartTextField(String text) { this(text,0); }
	public SmartTextField(int columns) { this(null,columns); }
	public SmartTextField() { this(null,0); }
	
/*
	nothing is fired when setText() is called.
*/
	public void setText(String text)
	{
		super.setText(text);
		setOldText(text);
	}

/*
	zeroLengthValid accessors.
	If set to true, checkText() will display an error if getText returns "" 
	and only fire a ChangeEvent once getText() returns a non-zero-length value.
*/
	public boolean isZeroLengthValid() { return(zeroLengthValid); }
	public void setZeroLengthValid(boolean zeroLengthValid) { this.zeroLengthValid=zeroLengthValid; }

/*
	Internal oldText accessors.
*/
	protected String getOldText() { return(oldText); }
	protected void setOldText(String oldText) { this.oldText=oldText; }
						  
/*
	Fires a ChangeEvent if the current value of getText() is different from oldText.
	Updates oldText after it fires.
*/
	protected void checkText()
	{
		String text=getText();
		if(text.equals("") && !isZeroLengthValid())
			displayError("You must enter some text in this field.");
		else if(!text.equals(getOldText()))
		{
			fireChangeEvent();
			setOldText(text);
		}
	}
	
/*
	Convinience method for displaying an error message (e.g. if the entered text is in some way invalid).
	After the message is confirmed, this textfield requests focus and selects its text for easy text correction.
	It sets its text to the last valid text so that the error can not be left unfixed.
*/
	public void displayError(String error)
	{
		setText(getOldText());
		JOptionPane.showMessageDialog(this,error,"Invalid Text Entry",JOptionPane.ERROR_MESSAGE);
		requestFocus();
		selectAll();
	}

/*
	Standard code to make this class a source of ChangeEvents.
*/
	protected EventListenerList listenerList=new EventListenerList();
	public void addChangeListener(ChangeListener cl) { listenerList.add(ChangeListener.class,cl); }
	public void removeChangeListener(ChangeListener cl) { listenerList.remove(ChangeListener.class,cl); }
	protected void fireChangeEvent()
	{
		ChangeEvent ce=new ChangeEvent(this);
		Object[] listeners=listenerList.getListenerList();
		for(int i=listeners.length-2;i>=0;i-=2) 
			if(listeners[i]==ChangeListener.class) 
				((ChangeListener)listeners[i+1]).stateChanged(ce);
	}
}
