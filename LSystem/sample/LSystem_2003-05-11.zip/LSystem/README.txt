---------------------------------------------------------------------------
COPYRIGHT NOTICE
---------------------------------------------------------------------------

LSystem - A Java Lindenmayer system renderer.

Copyright (C) 2003 Steven N. Severinghaus (sns@severinghaus.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You can find the full text of the license here:
http://www.gnu.org/copyleft/gpl.html

Please note that this also makes use of the wonder PngEnccoder
library by J. David Eisenberg: http://catcode.com/pngencoder/


---------------------------------------------------------------------------
INSTRUCTIONS
---------------------------------------------------------------------------

Update (2003.05.10):
I just optimized the inner loop to some extent, swapping LinkedLists
and ListIterators in for ArrayLists and for loops. For comparison, 22
iterations of the dragon fractal took about 100 hours before. Now it
takes about 2 minutes. Frreeeooww!

This code is old and cranky. Don't get your hopes up. If just running
LSystem.bat doesn't work for you, read on...

This needs to be run from the LSystem directory, i.e. the directory
that README.txt, paths, presets, etc. are in. So cd to that directory
in whatever way your OS lets you, then set your classpath to include
the classes directory, then just run "java LSystem" for the GUI. You
will get some useless debugging output on the console because I don't
remember where it's coming from and am too lazy to turn it off. Also
note that LSystem will save rendered paths in the paths directory,
which may need to get cleaned out occasionally.

To run the command line version, set up your classpath as described
above, then run something along the lines of:
java LSystem presets/presetfile.lsd iter width height
So to get 11 iterations of my "colon" fractal at 2000x2000 pixels:
java LSystem presets/set1/colon.lsd 11 2000 2000
The output will be saved as images/colon_11.png, so make sure that the
images directory exists and that you don't mind that file getting
overwritten.

To compile the source for yourself, just cd to the LSystem directory
and run "javac -d classes source/*.java". This should work fine with
the 1.4.1 JDK.


---------------------------------------------------------------------------
HISTORY
---------------------------------------------------------------------------

LSystem was written sometime around when I graduated from high school
in 1998. I received a great deal of interface help from Joseph Smarr
(http://www.stanford.edu/~jsmarr/), without which, LSystem would
probably not have been very usable. If I do any maintenance, the
updates will be posted at LSystem's home:
http://severinghaus.org/projects/lsystem/

Check out TODO.txt for some things that may fall under "maintenance".
I hope to eventually fix polygon rendering and add in some language
features to allow stochastic systems. Oh, and I need to add a way to
set the angle scale... it's hardcoded now.

